﻿namespace $safeprojectname$.Expressions
{
    public class MinDateTimeOperatorParameters : IExpressionParameter
    {
		public MinDateTimeOperatorParameters()
		{
		}
    }
}