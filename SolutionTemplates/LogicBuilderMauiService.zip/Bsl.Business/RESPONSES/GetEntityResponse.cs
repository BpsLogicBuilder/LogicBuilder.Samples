﻿using $ext_safeprojectname$.Domain;

namespace $safeprojectname$.Responses
{
    public class GetEntityResponse : BaseResponse
    {
        public EntityModelBase Entity { get; set; }
    }
}
