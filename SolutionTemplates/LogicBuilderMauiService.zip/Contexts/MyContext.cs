﻿using $ext_safeprojectname$.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace $safeprojectname$
{
    public class MyContext : BaseDbContext
    {
        public MyContext(DbContextOptions<MyContext> options) : base(options)
        {
        }

        public DbSet<Person> Persons { get; set; }
    }
}
