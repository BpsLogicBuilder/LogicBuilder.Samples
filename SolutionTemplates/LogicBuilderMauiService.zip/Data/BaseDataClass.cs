﻿using LogicBuilder.Data;

namespace $safeprojectname$
{
    abstract public class BaseDataClass : BaseData
    {
    }
}
