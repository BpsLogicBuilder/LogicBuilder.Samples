﻿namespace $safeprojectname$
{
    public class ConfigurationOptions
    {
        #region Constants
        public const string DEFAULTBASEBSLURL = "http://localhost:36525/api";
        #endregion Constants

        #region Properties
        public string BaseBslUrl { get; set; }
        #endregion Properties
    }
}
