﻿using LogicBuilder.EntityFrameworkCore.SqlServer.Repositories;

namespace $safeprojectname$
{
    public interface IMyRepository : IContextRepository
    {
    }
}
