﻿using AutoMapper;
using $safeprojectname$.Business.Requests;
using $safeprojectname$.Business.Responses;
using $safeprojectname$.Utils;
using $ext_safeprojectname$.Repositories;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace $safeprojectname$.Controllers
{
    [Produces("application/json")]
    [Route("api/Entity")]
    public class EntityController : Controller
    {
        private readonly IMapper mapper;
        private readonly IMyRepository repository;

        public EntityController(IMapper mapper, IMyRepository repository)
        {
            this.mapper = mapper;
            this.repository = repository;
        }

        [HttpPost("GetEntity")]
        public async Task<BaseResponse> GetEntity([FromBody] GetEntityRequest request) 
            => await RequestHelpers.GetEntity
            (
                request,
                repository,
                mapper
            );
    }
}
