﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class DistinctOperatorDescriptor : OperatorDescriptorBase
    {
		public OperatorDescriptorBase SourceOperand { get; set; }
    }
}