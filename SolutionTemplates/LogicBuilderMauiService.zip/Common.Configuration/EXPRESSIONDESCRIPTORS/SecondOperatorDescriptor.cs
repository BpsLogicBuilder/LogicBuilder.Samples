﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class SecondOperatorDescriptor : OperatorDescriptorBase
    {
		public OperatorDescriptorBase Operand { get; set; }
    }
}