﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class CeilingOperatorDescriptor : OperatorDescriptorBase
    {
		public OperatorDescriptorBase Operand { get; set; }
    }
}