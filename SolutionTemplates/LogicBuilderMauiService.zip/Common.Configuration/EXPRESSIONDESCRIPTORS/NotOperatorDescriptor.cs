﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class NotOperatorDescriptor : OperatorDescriptorBase
    {
		public OperatorDescriptorBase Operand { get; set; }
    }
}