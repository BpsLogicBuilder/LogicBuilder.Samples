﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class NotEqualsBinaryOperatorDescriptor : BinaryOperatorDescriptor
    {

    }
}