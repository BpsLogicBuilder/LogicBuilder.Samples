﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class MinDateTimeOperatorDescriptor : OperatorDescriptorBase
    {

    }
}