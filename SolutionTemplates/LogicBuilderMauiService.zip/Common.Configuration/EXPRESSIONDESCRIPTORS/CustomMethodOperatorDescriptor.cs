﻿using System.Reflection;

namespace $safeprojectname$.ExpressionDescriptors
{
    public class CustomMethodOperatorDescriptor : OperatorDescriptorBase
    {
		public MethodInfo MethodInfo { get; set; }
		public OperatorDescriptorBase[] Args { get; set; }
    }
}