﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class MaxDateTimeOperatorDescriptor : OperatorDescriptorBase
    {

    }
}