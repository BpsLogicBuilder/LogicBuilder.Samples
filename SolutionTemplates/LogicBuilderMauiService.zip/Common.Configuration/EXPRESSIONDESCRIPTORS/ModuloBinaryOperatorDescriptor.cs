﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class ModuloBinaryOperatorDescriptor : BinaryOperatorDescriptor
    {

    }
}