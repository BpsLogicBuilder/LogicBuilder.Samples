﻿using $ext_safeprojectname$.Domain;

namespace $safeprojectname$.Requests.TransientFlows
{
    public class SelectorFlowRequest
    {
        public EntityModelBase? Entity { get; set; }
        public string? ReloadItemsFlowName { get; set; }
    }
}
