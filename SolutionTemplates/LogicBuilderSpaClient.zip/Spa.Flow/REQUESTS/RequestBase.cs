﻿using $safeprojectname$.Requests.Json;
using $safeprojectname$.ScreenSettings;
using $safeprojectname$.ScreenSettings.Views;
using System.Text.Json.Serialization;

namespace $safeprojectname$.Requests
{
    [JsonConverter(typeof(RequestConverter))]
    abstract public class RequestBase
    {
        public CommandButtonRequest? CommandButtonRequest { get; set; }
        public FlowState? FlowState { get; set; }
        abstract public ViewType ViewType { get; set; }
    }
}
