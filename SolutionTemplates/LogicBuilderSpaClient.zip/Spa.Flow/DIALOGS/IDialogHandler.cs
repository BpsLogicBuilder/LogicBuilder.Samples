﻿using $safeprojectname$.Requests;

namespace $safeprojectname$.Dialogs
{
    public interface IDialogHandler
    {
        void Complete(IFlowManager flowManager, RequestBase request);
    }
}
