﻿using $safeprojectname$.Requests;

namespace $safeprojectname$.Dialogs
{
    public class DefaultDialogHandler : BaseDialogHandler
    {
        public override void Complete(IFlowManager flowManager, RequestBase request)
        {
            base.Complete(flowManager, request);
        }
    }
}
