﻿namespace $safeprojectname$.Responses.TransientFlows
{
    public class ErrorFlowResponse : BaseFlowResponse
    {
    }
}
