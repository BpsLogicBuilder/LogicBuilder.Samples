﻿using AutoMapper;
using $safeprojectname$.Cache;
using $safeprojectname$.Requests;
using $safeprojectname$.ScreenSettings;
using LogicBuilder.RulesDirector;

namespace $safeprojectname$
{
    public interface IFlowManager
    {
        DirectorBase Director { get; }
        FlowDataCache FlowDataCache { get; set; }
        Progress Progress { get; }
        ICustomActions CustomActions { get; }
        ICustomDialogs CustomDialogs { get; }
        IFlowActivity FlowActivity { get; }
        IMapper Mapper { get; }

        FlowSettings Start(string module, int stage);
        FlowSettings Next(RequestBase request);
        FlowSettings NavStart(NavBarRequest navBarRequest);
        void RunFlow(string flowName);
        void FlowComplete();
        void Terminate();
        void SetCurrentBusinessBackupData();
    }
}
