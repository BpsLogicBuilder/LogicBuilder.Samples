﻿using $safeprojectname$.Requests.TransientFlows;
using $safeprojectname$.Responses.TransientFlows;

namespace $safeprojectname$
{
    public interface ITransientFlowHelper
    {
        BaseFlowResponse RunSelectorFlow(SelectorFlowRequest selectorFlowRequest);
    }
}
