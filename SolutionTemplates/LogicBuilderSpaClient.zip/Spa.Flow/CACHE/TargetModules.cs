﻿namespace $safeprojectname$.Cache
{
    public static class TargetModules
    {
        public const int Home = 0;
        public const int About = 1;
        public const int Students = 2;
        public const int Departments = 3;
        public const int Courses = 4;
        public const int Instructors = 5;
    }
}
