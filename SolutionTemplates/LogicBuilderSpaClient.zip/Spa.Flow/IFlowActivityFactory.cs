﻿using LogicBuilder.RulesDirector;

namespace $safeprojectname$
{
    public interface IFlowActivityFactory
    {
        IFlowActivity Create(IFlowManager flowManager);
    }
}
