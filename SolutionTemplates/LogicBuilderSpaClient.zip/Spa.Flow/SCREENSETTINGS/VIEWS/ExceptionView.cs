﻿namespace $safeprojectname$.ScreenSettings.Views
{
    public class ExceptionView
    {
        public string? Message { get; set; }
    }
}
