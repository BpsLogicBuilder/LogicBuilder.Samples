﻿using $safeprojectname$.ExpressionDescriptors;

namespace $safeprojectname$.ExpansionDescriptors
{
    public class SelectExpandItemFilterDescriptor
    {
        public FilterLambdaOperatorDescriptor FilterLambdaOperator { get; set; }
    }
}
