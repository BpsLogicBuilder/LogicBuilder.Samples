﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class AndBinaryOperatorDescriptor : BinaryOperatorDescriptor
    {

    }
}