﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class ConvertCharArrayToStringOperatorDescriptor : OperatorDescriptorBase
    {
		public OperatorDescriptorBase SourceOperand { get; set; }
    }
}