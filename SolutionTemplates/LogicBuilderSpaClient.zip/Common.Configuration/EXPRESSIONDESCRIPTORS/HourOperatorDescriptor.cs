﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class HourOperatorDescriptor : OperatorDescriptorBase
    {
		public OperatorDescriptorBase Operand { get; set; }
    }
}