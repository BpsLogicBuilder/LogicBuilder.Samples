﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class MinOperatorDescriptor : SelectorMethodOperatorDescriptorBase
    {

    }
}