﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class DivideBinaryOperatorDescriptor : BinaryOperatorDescriptor
    {

    }
}