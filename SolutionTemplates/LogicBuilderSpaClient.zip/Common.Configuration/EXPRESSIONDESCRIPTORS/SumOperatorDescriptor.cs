﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class SumOperatorDescriptor : SelectorMethodOperatorDescriptorBase
    {

    }
}