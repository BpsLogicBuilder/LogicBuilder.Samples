﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class FloorOperatorDescriptor : OperatorDescriptorBase
    {
		public OperatorDescriptorBase Operand { get; set; }
    }
}