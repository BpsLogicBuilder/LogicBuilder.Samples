﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class LessThanBinaryOperatorDescriptor : BinaryOperatorDescriptor
    {

    }
}