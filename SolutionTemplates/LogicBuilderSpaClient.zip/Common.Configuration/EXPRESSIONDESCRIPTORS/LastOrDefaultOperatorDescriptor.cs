﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class LastOrDefaultOperatorDescriptor : FilterMethodOperatorDescriptorBase
    {

    }
}