﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class RoundOperatorDescriptor : OperatorDescriptorBase
    {
		public OperatorDescriptorBase Operand { get; set; }
    }
}