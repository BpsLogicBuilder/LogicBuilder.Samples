﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class TrimOperatorDescriptor : OperatorDescriptorBase
    {
		public OperatorDescriptorBase Operand { get; set; }
    }
}