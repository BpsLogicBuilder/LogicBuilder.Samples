﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class FractionalSecondsOperatorDescriptor : OperatorDescriptorBase
    {
		public OperatorDescriptorBase Operand { get; set; }
    }
}