﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class TimeOperatorDescriptor : OperatorDescriptorBase
    {
		public OperatorDescriptorBase Operand { get; set; }
    }
}