﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class YearOperatorDescriptor : OperatorDescriptorBase
    {
		public OperatorDescriptorBase Operand { get; set; }
    }
}