﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Common
{
    public enum AbstractControlEnum
    {
        FormControl,
        MultiSelectFormControl,
        FormGroup,
        FormGroupArray,
        GroupBox
    }
}
