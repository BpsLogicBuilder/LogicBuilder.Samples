﻿using System.Collections.Generic;

namespace $safeprojectname$.Common
{
    public class ContentTemplateView
    {
		public string Title { get; set; }
		public string TemplateName { get; set; }
    }
}