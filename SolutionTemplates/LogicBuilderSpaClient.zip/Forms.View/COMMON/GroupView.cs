﻿using System.Collections.Generic;

namespace $safeprojectname$.Common
{
    public class GroupView
    {
		public string Field { get; set; }
		public string Dir { get; set; }
		public List<AggregateDefinitionView> Aggregates { get; set; }
    }
}