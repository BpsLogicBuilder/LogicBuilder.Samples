﻿using System.Collections.Generic;

namespace $safeprojectname$.Common
{
    public class AggregateTemplateFieldsView
    {
		public string Label { get; set; }
		public string Function { get; set; }
    }
}