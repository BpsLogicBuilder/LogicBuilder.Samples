﻿using $ext_safeprojectname$.Common.Configuration.ExpansionDescriptors;

namespace $safeprojectname$.Common
{
    public class RequestDetailsView
    {
		public string ModelType { get; set; }
		public string DataType { get; set; }
        public string ModelReturnType { get; set; }
        public string DataReturnType { get; set; }
        public string DataSourceUrl { get; set; }
		public SelectExpandDefinitionDescriptor SelectExpandDefinition { get; set; }
	}
}