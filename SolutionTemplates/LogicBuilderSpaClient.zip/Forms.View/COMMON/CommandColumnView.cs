﻿using System.Collections.Generic;

namespace $safeprojectname$.Common
{
    public class CommandColumnView
    {
		public string Title { get; set; }
		public int? Width { get; set; }
    }
}