﻿using $safeprojectname$.Common.Json;
using System.Text.Json.Serialization;

namespace $safeprojectname$.Common
{
    [JsonConverter(typeof(FormItemSettingViewConverter))]
    abstract public class FormItemSettingView
    {
		abstract public AbstractControlEnum AbstractControlType { get; set; }
        public string TypeFullName => this.GetType().AssemblyQualifiedName;
    }
}