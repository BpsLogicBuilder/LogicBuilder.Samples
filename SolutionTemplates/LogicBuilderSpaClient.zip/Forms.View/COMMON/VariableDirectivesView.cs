﻿using System.Collections.Generic;

namespace $safeprojectname$.Common
{
    public class VariableDirectivesView
    {
		public string Field { get; set; }
		public List<DirectiveView> ConditionalDirectives { get; set; }
    }
}