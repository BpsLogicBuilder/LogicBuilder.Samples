﻿using System.Collections.Generic;

namespace $safeprojectname$.Common
{
    public class SelectView
    {
		public string FieldName { get; set; }
		public string SourceMember { get; set; }
    }
}