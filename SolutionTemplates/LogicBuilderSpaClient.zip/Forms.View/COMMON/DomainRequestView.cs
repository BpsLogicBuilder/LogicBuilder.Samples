﻿using System.Collections.Generic;

namespace $safeprojectname$.Common
{
    public class DomainRequestView
    {
		public DataRequestStateView State { get; set; }
		public RequestDetailsView RequestDetails { get; set; }
    }
}