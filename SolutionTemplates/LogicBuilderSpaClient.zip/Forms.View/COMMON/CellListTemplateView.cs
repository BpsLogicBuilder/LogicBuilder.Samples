﻿using System.Collections.Generic;

namespace $safeprojectname$.Common
{
    public class CellListTemplateView
    {
		public string TemplateName { get; set; }
		public string DisplayMember { get; set; }
    }
}