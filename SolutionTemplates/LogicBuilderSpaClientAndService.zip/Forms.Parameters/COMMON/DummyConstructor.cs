﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Common
{
    public class DummyConstructor
    {
        public DummyConstructor
        (
            DetailFormSettingsParameters form,
            DetailFieldSettingParameters field,
            DetailGroupSettingsParameters group,
            DetailListSettingsParameters list,
            FormControlSettingsParameters formControlSettings,
            FormGroupArraySettingsParameters formGroupArraySettings,
            FormGroupSettingsParameters formGroupSettings,
            FormGroupBoxSettingsParameters formGroupBoxSettings,
            MultiSelectFormControlSettingsParameters multiSelectFormControlSettings,
            CommandButtonParameters commandButtonData,
            ValidatorArgumentParameters validatorArguments
        )
        {
        }
    }
}
