﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Common
{
    public abstract class DetailItemParameters
    {
        abstract public DetailItemEnum DetailType { get; }
    }
}
