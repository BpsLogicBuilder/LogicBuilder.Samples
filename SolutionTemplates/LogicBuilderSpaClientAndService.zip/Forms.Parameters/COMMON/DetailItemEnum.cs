﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Common
{
    public enum DetailItemEnum
    {
        Field,
        Group,
        List
    }
}
