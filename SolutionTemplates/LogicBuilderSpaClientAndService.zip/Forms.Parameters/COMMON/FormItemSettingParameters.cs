﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Common
{
    //FormGroupSettingsParameters, FormControlSettingsParameters,  MultiSelectFormControlSettingsParameters, FormGroupArraySettingsParameters
    public abstract class FormItemSettingParameters
    {
        abstract public AbstractControlEnum AbstractControlType { get; }
    }
}
