﻿using LogicBuilder.Attributes;

namespace $safeprojectname$
{
    public interface ICustomActions
    {
        [AlsoKnownAs("WriteToLog")]
        void WriteToLog(string message);
    }
}
