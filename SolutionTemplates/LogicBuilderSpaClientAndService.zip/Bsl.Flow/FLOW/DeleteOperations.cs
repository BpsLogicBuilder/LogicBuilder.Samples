﻿using AutoMapper;
using $ext_safeprojectname$.Common.Utils;
using $ext_safeprojectname$.Parameters.Expressions;
using LogicBuilder.Attributes;
using LogicBuilder.Data;
using LogicBuilder.Domain;
using LogicBuilder.EntityFrameworkCore.SqlServer.Repositories;
using LogicBuilder.Expressions.Utils.ExpressionBuilder;
using System;
using System.Linq.Expressions;

namespace $safeprojectname$
{
    internal class DeleteOperations<TModel, TData> where TModel : BaseModel where TData : BaseData
    {
        [AlsoKnownAs("Delete")]
        [FunctionGroup(FunctionGroup.Standard)]
        public static bool Delete(IContextRepository repository,
            IMapper mapper,
            FilterLambdaOperatorParameters filterExpression)
            => repository.DeleteAsync<TModel, TData>
            (
                GetFilter(mapper.MapToOperator(filterExpression))
            ).Result;

        public static Expression<Func<TModel, bool>> GetFilter(IExpressionPart filterExpression)
            => (Expression<Func<TModel, bool>>)filterExpression?.Build();
    }
}
