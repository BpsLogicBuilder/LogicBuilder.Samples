﻿using AutoMapper;
using $ext_safeprojectname$.Stores;
using LogicBuilder.EntityFrameworkCore.SqlServer.Repositories;

namespace $safeprojectname$
{
    public class MyRepository : ContextRepositoryBase, IMyRepository
    {
        public MyRepository(IMyStore store, IMapper mapper) : base(store, mapper)
        {
        }
    }
}
