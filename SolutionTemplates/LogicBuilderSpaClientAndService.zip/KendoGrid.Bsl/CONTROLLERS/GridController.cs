﻿using AutoMapper;
using $safeprojectname$.Business.Requests;
using $safeprojectname$.Utils;
using $ext_safeprojectname$.Repositories;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace $safeprojectname$.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GridController : Controller
    {
        private readonly IMapper mapper;
        private readonly IMyRepository repository;

        public GridController(IMapper mapper, IMyRepository repository)
        {
            this.mapper = mapper;
            this.repository = repository;
        }


        [HttpPost("GetData")]
        public Task<DataSourceResult> GetData([FromBody] KendoGridDataRequest request) 
            => RequestHelpers.GetData
            (
                request,
                repository,
                mapper
            );
    }
}
