﻿using $safeprojectname$.ExpressionDescriptors;
using $ext_safeprojectname$.Utils;
using System;

namespace $safeprojectname$.Json
{
    public class DescriptorConverter : JsonTypeConverter<OperatorDescriptorBase>
    {
        public override string TypePropertyName => "TypeString";
    }
}
