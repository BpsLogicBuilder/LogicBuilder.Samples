﻿using LogicBuilder.Expressions.Utils.Strutures;

namespace $safeprojectname$.ExpressionDescriptors
{
    public class OrderByOperatorDescriptor : SelectorMethodOperatorDescriptorBase
    {
		public ListSortDirection SortDirection { get; set; }
    }
}