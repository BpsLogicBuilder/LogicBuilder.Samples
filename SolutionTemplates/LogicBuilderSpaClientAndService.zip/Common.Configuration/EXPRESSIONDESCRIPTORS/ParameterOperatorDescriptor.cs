﻿using System.Collections.Generic;

namespace $safeprojectname$.ExpressionDescriptors
{
    public class ParameterOperatorDescriptor : OperatorDescriptorBase
    {
		public string ParameterName { get; set; }
    }
}