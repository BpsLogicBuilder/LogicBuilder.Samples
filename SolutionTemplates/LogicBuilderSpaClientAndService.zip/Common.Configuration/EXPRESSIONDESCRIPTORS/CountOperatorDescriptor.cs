﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class CountOperatorDescriptor : FilterMethodOperatorDescriptorBase
    {

    }
}