﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class DateOperatorDescriptor : OperatorDescriptorBase
    {
		public OperatorDescriptorBase Operand { get; set; }
    }
}