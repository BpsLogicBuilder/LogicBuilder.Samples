﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class SingleOrDefaultOperatorDescriptor : FilterMethodOperatorDescriptorBase
    {

    }
}