﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class GreaterThanBinaryOperatorDescriptor : BinaryOperatorDescriptor
    {

    }
}