﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class FirstOrDefaultOperatorDescriptor : FilterMethodOperatorDescriptorBase
    {

    }
}