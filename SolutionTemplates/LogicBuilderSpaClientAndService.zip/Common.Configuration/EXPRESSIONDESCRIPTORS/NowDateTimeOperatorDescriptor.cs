﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class NowDateTimeOperatorDescriptor : OperatorDescriptorBase
    {

    }
}