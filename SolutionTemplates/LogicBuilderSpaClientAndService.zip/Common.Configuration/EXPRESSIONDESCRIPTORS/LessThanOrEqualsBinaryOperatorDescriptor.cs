﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class LessThanOrEqualsBinaryOperatorDescriptor : BinaryOperatorDescriptor
    {

    }
}