﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class LastOperatorDescriptor : FilterMethodOperatorDescriptorBase
    {

    }
}