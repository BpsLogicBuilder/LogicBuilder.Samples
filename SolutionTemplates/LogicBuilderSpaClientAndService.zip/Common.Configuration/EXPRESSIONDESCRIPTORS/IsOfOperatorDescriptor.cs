﻿using System;

namespace $safeprojectname$.ExpressionDescriptors
{
    public class IsOfOperatorDescriptor : OperatorDescriptorBase
    {
		public OperatorDescriptorBase Operand { get; set; }
		public string Type { get; set; }
    }
}