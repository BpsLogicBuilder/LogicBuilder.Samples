﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class GreaterThanOrEqualsBinaryOperatorDescriptor : BinaryOperatorDescriptor
    {

    }
}