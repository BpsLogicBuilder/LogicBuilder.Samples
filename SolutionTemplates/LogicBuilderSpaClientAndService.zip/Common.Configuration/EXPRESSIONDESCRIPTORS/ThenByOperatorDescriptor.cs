﻿using LogicBuilder.Expressions.Utils.Strutures;

namespace $safeprojectname$.ExpressionDescriptors
{
    public class ThenByOperatorDescriptor : SelectorMethodOperatorDescriptorBase
    {
		public ListSortDirection SortDirection { get; set; }
    }
}