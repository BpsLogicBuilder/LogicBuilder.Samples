﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class LengthOperatorDescriptor : OperatorDescriptorBase
    {
		public OperatorDescriptorBase Operand { get; set; }
    }
}