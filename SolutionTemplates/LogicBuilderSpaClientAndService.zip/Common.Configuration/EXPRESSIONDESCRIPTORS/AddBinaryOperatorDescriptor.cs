﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class AddBinaryOperatorDescriptor : BinaryOperatorDescriptor
    {

    }
}