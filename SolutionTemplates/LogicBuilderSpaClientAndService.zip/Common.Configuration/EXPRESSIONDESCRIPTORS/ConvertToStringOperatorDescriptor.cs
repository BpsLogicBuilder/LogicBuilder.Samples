﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class ConvertToStringOperatorDescriptor : OperatorDescriptorBase
    {
		public OperatorDescriptorBase SourceOperand { get; set; }
    }
}