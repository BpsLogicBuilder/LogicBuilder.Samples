﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class ToUpperOperatorDescriptor : OperatorDescriptorBase
    {
		public OperatorDescriptorBase Operand { get; set; }
    }
}