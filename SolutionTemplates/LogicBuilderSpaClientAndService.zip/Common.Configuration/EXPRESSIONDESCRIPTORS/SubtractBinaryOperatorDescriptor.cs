﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class SubtractBinaryOperatorDescriptor : BinaryOperatorDescriptor
    {

    }
}