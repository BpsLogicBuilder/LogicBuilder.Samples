﻿using $ext_safeprojectname$.Utils;

namespace $safeprojectname$.Json
{
    public class ModelConverter : JsonTypeConverter<EntityModelBase>
    {
        public override string TypePropertyName => "TypeFullName";
    }
}
