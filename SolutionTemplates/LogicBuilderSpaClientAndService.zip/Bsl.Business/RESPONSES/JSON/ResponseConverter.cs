﻿using $ext_safeprojectname$.Utils;

namespace $safeprojectname$.Responses.Json
{
    public class ResponseConverter : JsonTypeConverter<BaseResponse>
    {
        public override string TypePropertyName => "TypeFullName";
    }
}
