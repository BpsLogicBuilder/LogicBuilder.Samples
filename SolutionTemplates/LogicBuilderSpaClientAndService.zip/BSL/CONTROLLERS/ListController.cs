﻿using AutoMapper;
using $safeprojectname$.Business.Requests;
using $safeprojectname$.Business.Responses;
using $safeprojectname$.Utils;
using $ext_safeprojectname$.Repositories;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace $safeprojectname$.Controllers
{
    [Produces("application/json")]
    [Route("api/List")]
    public class ListController : Controller
    {
        private readonly IMapper mapper;
        private readonly IMyRepository repository;

        public ListController(IMapper mapper, IMyRepository repository)
        {
            this.mapper = mapper;
            this.repository = repository;
        }

        [HttpPost("GetList")]
        public async Task<BaseResponse> GetList([FromBody] GetTypedListRequest request)
        {
            return await RequestHelpers.GetList
            (
                request,
                repository,
                mapper
            );
        }
    }
}
