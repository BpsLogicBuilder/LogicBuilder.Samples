﻿using System.Collections.Generic;

namespace $safeprojectname$.Common
{
    public class DirectiveView
    {
		public DirectiveDescriptionView DirectiveDescription { get; set; }
		public ConditionGroupView ConditionGroup { get; set; }
    }
}