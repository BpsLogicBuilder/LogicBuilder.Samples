﻿using $ext_safeprojectname$.Common.Configuration.ExpansionDescriptors;
using $ext_safeprojectname$.Common.Configuration.ExpressionDescriptors;

namespace $safeprojectname$.Common
{
    public class FormRequestDetailsView
    {
        public string GetUrl { get; set; }
        public string AddUrl { get; set; }
        public string UpdateUrl { get; set; }
        public string DeleteUrl { get; set; }
        public string ModelType { get; set; }
        public string DataType { get; set; }
        public FilterLambdaOperatorDescriptor Filter { get; set; }
        public SelectExpandDefinitionDescriptor SelectExpandDefinition { get; set; }
    }
}
