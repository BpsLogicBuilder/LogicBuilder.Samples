﻿using System.Collections.Generic;

namespace $safeprojectname$.Common
{
    public class AggregateTemplateView
    {
		public string TemplateName { get; set; }
		public List<AggregateTemplateFieldsView> Aggregates { get; set; }
    }
}