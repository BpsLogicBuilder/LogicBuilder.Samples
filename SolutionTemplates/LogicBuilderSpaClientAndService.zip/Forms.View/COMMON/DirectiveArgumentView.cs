﻿using System.Collections.Generic;

namespace $safeprojectname$.Common
{
    public class DirectiveArgumentView
    {
		public string Name { get; set; }
		public object Value { get; set; }
    }
}