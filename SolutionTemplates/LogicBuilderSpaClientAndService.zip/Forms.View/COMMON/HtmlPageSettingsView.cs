﻿using System.Collections.Generic;

namespace $safeprojectname$.Common
{
    public class HtmlPageSettingsView
    {
		public ContentTemplateView ContentTemplate { get; set; }
		public MessageTemplateView MessageTemplate { get; set; }
    }
}