﻿using System.Collections.Generic;

namespace $safeprojectname$.Common
{
    public class CellTemplateView
    {
		public string TemplateName { get; set; }
    }
}