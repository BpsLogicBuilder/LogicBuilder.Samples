﻿using System.Collections.Generic;

namespace $safeprojectname$.Common
{
    public class DetailFieldTemplateView
    {
		public string TemplateName { get; set; }
    }
}