﻿using System.Collections.Generic;

namespace $safeprojectname$.Common
{
    public class TextFieldTemplateView
    {
		public string TemplateName { get; set; }
    }
}