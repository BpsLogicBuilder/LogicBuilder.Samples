﻿using System.Collections.Generic;

namespace $safeprojectname$.Common
{
    public class ValidationMethodView
    {
		public string Method { get; set; }
		public string Message { get; set; }
    }
}