﻿using System.Collections.Generic;

namespace $safeprojectname$.Common
{
    public class ValidationMessageView
    {
		public string Field { get; set; }
		public Dictionary<string, string> Methods { get; set; }
    }
}