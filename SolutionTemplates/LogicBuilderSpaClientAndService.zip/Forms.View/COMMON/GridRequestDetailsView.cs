﻿using $ext_safeprojectname$.Common.Configuration.ExpansionDescriptors;

namespace $safeprojectname$.Common
{
    public class GridRequestDetailsView
    {
        public string ModelType { get; set; }
        public string DataType { get; set; }
        public string DataSourceUrl { get; set; }
        public SelectExpandDefinitionDescriptor SelectExpandDefinition { get; set; }
    }
}
