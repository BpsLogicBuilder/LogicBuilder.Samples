﻿using System.Collections.Generic;

namespace $safeprojectname$.Common
{
    public class DetailListTemplateView
    {
		public string TemplateName { get; set; }
    }
}