﻿using System.Collections.Generic;

namespace $safeprojectname$.Common
{
    public class MessageTemplateView
    {
		public string Caption { get; set; }
		public string Message { get; set; }
		public string TemplateName { get; set; }
    }
}