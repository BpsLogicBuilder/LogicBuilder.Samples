﻿namespace $safeprojectname$.Common
{
    public enum DetailItemEnum
    {
		Field,
		Group,
		List
    }
}