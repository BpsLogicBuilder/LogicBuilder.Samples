﻿using System.Collections.Generic;

namespace $safeprojectname$.Common
{
    public class AggregateDefinitionView
    {
		public string Field { get; set; }
		public string Aggregate { get; set; }
    }
}