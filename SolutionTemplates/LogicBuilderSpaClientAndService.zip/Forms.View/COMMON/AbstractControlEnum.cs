﻿namespace $safeprojectname$.Common
{
    public enum AbstractControlEnum
    {
		FormControl,
		MultiSelectFormControl,
		FormGroup,
		FormGroupArray,
		GroupBox
	}
}