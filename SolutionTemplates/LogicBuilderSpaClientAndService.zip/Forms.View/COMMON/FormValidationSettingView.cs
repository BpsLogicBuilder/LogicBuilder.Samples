﻿using System.Collections.Generic;

namespace $safeprojectname$.Common
{
    public class FormValidationSettingView
    {
		public object DefaultValue { get; set; }
		public List<ValidatorDescriptionView> Validators { get; set; }
    }
}