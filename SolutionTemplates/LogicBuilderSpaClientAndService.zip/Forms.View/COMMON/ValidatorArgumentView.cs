﻿using System.Collections.Generic;

namespace $safeprojectname$.Common
{
    public class ValidatorArgumentView
    {
		public string Name { get; set; }
		public object Value { get; set; }
    }
}