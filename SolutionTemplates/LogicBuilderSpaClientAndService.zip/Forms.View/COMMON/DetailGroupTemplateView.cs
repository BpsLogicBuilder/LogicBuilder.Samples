﻿using System.Collections.Generic;

namespace $safeprojectname$.Common
{
    public class DetailGroupTemplateView
    {
		public string TemplateName { get; set; }
    }
}