﻿using $ext_safeprojectname$.Utils;

namespace $safeprojectname$.Common.Json
{
    public class DetailItemViewConverter : JsonTypeConverter<DetailItemView>
    {
        public override string TypePropertyName => nameof(DetailItemView.TypeFullName);
    }
}
