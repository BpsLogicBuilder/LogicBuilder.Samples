﻿using $ext_safeprojectname$.Utils;

namespace $safeprojectname$.Common.Json
{
    public class FormItemSettingViewConverter : JsonTypeConverter<FormItemSettingView>
    {
        public override string TypePropertyName => nameof(FormItemSettingView.TypeFullName);
    }
}
