﻿using $ext_safeprojectname$.Domain;
using $safeprojectname$.ScreenSettings.Views;

namespace $safeprojectname$.Requests
{
    public class GridRequest : RequestBase
    {
        public EntityModelBase? Entity { get; set; }
        public override ViewType ViewType { get; set; }
    }
}
