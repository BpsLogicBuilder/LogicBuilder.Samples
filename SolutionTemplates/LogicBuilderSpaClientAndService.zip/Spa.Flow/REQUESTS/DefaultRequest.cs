﻿using $safeprojectname$.ScreenSettings.Views;

namespace $safeprojectname$.Requests
{
    public class DefaultRequest : RequestBase
    {
        public override ViewType ViewType { get; set; }
    }
}
