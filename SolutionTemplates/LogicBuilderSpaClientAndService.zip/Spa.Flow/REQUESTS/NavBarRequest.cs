﻿namespace $safeprojectname$.Requests
{
    public class NavBarRequest
    {
        public string? InitialModuleName { get; set; }
        public int TargetModule { get; set; }
    }
}
