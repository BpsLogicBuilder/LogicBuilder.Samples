﻿namespace $safeprojectname$.Requests
{
    public class CommandButtonRequest
    {
        public string? NewSelection { get; set; }
        public bool Cancel { get; set; }
    }
}
