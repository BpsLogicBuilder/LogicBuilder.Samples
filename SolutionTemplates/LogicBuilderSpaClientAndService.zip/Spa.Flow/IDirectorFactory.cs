﻿using LogicBuilder.RulesDirector;

namespace $safeprojectname$
{
    public interface IDirectorFactory
    {
        DirectorBase Create(IFlowManager flowManager);
    }
}
