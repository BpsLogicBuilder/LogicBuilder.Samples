﻿using $ext_safeprojectname$.Common.Configuration.ExpressionDescriptors;

namespace $safeprojectname$.Responses.TransientFlows
{
    public class SelectorFlowResponse : BaseFlowResponse
    {
        public SelectorLambdaOperatorDescriptor? Selector { get; set; }
    }
}
