﻿using $ext_safeprojectname$.Forms.View.Common;
using $safeprojectname$.ScreenSettings.Views;
using $ext_safeprojectname$.Utils;
using System;

namespace $safeprojectname$.ScreenSettings.Json
{
    public class ScreenSettingsConverter : JsonTypeConverter<ScreenSettingsBase>
    {
        public override string TypePropertyName => nameof(ScreenSettingsBase.TypeFullName);
    }
}
