﻿namespace $safeprojectname$.ScreenSettings.Views
{
    public enum ViewType
    {
        Grid,
        Edit,
        Create,
        Detail,
        Delete,
        Html,
        List,
        FlowComplete,
        Exception
    }
}
