﻿using $safeprojectname$.ScreenSettings.Navigation;
using $safeprojectname$.ScreenSettings.Views;
using System.Collections.Generic;

namespace $safeprojectname$.Cache
{
    public class FlowDataCache
    {
        public RequestedFlowStage RequestedFlowStage { get; set; } = new RequestedFlowStage();
        public NavigationBar NavigationBar { get; set; } = new NavigationBar();
        public ScreenSettingsBase? ScreenSettings { get; set; }
        public Dictionary<string, object> Items { get; set; } = new Dictionary<string, object>();
    }
}
