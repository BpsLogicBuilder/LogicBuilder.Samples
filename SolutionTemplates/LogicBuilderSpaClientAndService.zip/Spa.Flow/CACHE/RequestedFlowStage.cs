﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Cache
{
    public class RequestedFlowStage
    {
        public string InitialModule { get; set; }
        public int TargetModule { get; set; }
    }
}
