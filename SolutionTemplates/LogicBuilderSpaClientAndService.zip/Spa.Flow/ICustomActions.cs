﻿using $safeprojectname$.ScreenSettings.Navigation;
using LogicBuilder.Attributes;

namespace $safeprojectname$
{
    public interface ICustomActions
    {
        [AlsoKnownAs("SetupNavigationMenu")]
        void UpdateNavigationBar(NavigationBar navBar);
    }
}
