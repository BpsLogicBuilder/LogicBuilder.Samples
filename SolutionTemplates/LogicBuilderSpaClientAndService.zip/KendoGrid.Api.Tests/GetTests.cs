﻿using $ext_safeprojectname$.Data.Entities;
using $ext_safeprojectname$.Domain.Entities;
using $ext_safeprojectname$.KendoGrid.Bsl.Business.Requests;
using $ext_safeprojectname$.Web.Utils;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using Xunit;

namespace $safeprojectname$
{
    public class GetTests
    {
        public GetTests()
        {
            Initialize();
        }

        #region Fields
        private IServiceProvider serviceProvider;
        private IHttpClientFactory clientFactory;
        private const string BASE_URL = "http://localhost:12055/";
        #endregion Fields

        #region Helpers
        [MemberNotNull(nameof(clientFactory), nameof(serviceProvider))]
        private void Initialize()
        {
            IServiceCollection services = new ServiceCollection();
            services.AddHttpClient();
            serviceProvider = services.BuildServiceProvider();

            this.clientFactory = serviceProvider.GetRequiredService<IHttpClientFactory>();
        }
        #endregion Helpers


        [Fact]
        public async void Get_persons_ungrouped_with_aggregates()
        {
            var request = new KendoGridDataRequest
            {
                Options = new KendoGridDataSourceRequestOptions
                {
                    Aggregate = "lastName-count~dateOfBirth-min",
                    Filter = null,
                    Group = null,
                    Page = 1,
                    Sort = "dateOfBirth-asc",
                    PageSize = 5
                },
                ModelType = typeof(PersonModel).AssemblyQualifiedName,
                DataType = typeof(Person).AssemblyQualifiedName
            };
            var result = await this.clientFactory.PostAsync<System.Text.Json.Nodes.JsonObject>
            (
                "api/Grid/GetData",
                JsonSerializer.Serialize
                (
                    request
                ),
                BASE_URL
            );

            Assert.True(result.Any());
        }
    }
}
