﻿using $safeprojectname$.Settings.Screen;

namespace $safeprojectname$.Cache
{
    public class ScreenData
    {
        public ScreenSettingsBase ScreenSettings { get; set; }
    }
}
