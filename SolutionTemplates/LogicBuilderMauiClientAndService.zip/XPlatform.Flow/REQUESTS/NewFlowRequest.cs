﻿namespace $safeprojectname$.Requests
{
    public class NewFlowRequest
    {
        public string InitialModuleName { get; set; }
    }
}
