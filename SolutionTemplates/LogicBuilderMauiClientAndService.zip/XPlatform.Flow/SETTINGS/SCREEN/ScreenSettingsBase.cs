﻿using $ext_safeprojectname$.Forms.Configuration;
using System.Collections.Generic;

namespace $safeprojectname$.Settings.Screen
{
    public abstract class ScreenSettingsBase
    {
        abstract public ViewType ViewType { get; }
        public IEnumerable<CommandButtonDescriptor> CommandButtons { get; set; }
    }
}
