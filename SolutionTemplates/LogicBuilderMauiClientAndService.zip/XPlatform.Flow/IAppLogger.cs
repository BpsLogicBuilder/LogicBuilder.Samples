﻿namespace $safeprojectname$
{
    public interface IAppLogger
    {
        void LogMessage(string group, string message);
    }
}
