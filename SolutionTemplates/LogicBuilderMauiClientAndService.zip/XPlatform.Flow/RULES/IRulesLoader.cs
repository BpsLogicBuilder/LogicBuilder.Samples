﻿using $ext_safeprojectname$.Domain.Entities;

namespace $safeprojectname$.Rules
{
    public interface IRulesLoader
    {
        void LoadRules(RulesModuleModel modules, RulesCache cache);
    }
}
