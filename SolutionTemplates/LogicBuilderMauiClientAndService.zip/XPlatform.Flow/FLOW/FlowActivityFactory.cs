﻿using LogicBuilder.RulesDirector;

namespace $safeprojectname$
{
    public class FlowActivityFactory
    {
        public IFlowActivity Create(IFlowManager flowManager)
            => new FlowActivity(flowManager);
    }
}
