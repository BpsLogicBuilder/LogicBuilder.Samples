﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class SelectOperatorDescriptor : SelectorMethodOperatorDescriptorBase
    {

    }
}