﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class ConvertToNullableUnderlyingValueOperatorDescriptor : OperatorDescriptorBase
    {
		public OperatorDescriptorBase SourceOperand { get; set; }
    }
}