﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class TotalSecondsOperatorDescriptor : OperatorDescriptorBase
    {
		public OperatorDescriptorBase Operand { get; set; }
    }
}