﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class EqualsBinaryOperatorDescriptor : BinaryOperatorDescriptor
    {

    }
}