﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class DayOperatorDescriptor : OperatorDescriptorBase
    {
		public OperatorDescriptorBase Operand { get; set; }
    }
}