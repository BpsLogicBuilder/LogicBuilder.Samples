﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class ConvertToNumericDateOperatorDescriptor : OperatorDescriptorBase
    {
		public OperatorDescriptorBase SourceOperand { get; set; }
    }
}