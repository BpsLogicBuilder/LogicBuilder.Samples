﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class WhereOperatorDescriptor : FilterMethodOperatorDescriptorBase
    {

    }
}