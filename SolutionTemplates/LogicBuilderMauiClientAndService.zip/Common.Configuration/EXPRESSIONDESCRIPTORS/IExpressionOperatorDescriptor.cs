﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public interface IExpressionOperatorDescriptor
    {
    }
}
