﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class MultiplyBinaryOperatorDescriptor : BinaryOperatorDescriptor
    {

    }
}