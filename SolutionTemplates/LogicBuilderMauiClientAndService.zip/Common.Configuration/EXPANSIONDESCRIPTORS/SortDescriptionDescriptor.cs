﻿using LogicBuilder.Expressions.Utils.Strutures;

namespace $safeprojectname$.ExpansionDescriptors
{
    public class SortDescriptionDescriptor
    {
        public string PropertyName { get; set; }
        public ListSortDirection SortDirection { get; set; }
    }
}
