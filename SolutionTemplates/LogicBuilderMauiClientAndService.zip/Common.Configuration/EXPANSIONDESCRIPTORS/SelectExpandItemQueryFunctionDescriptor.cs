﻿namespace $safeprojectname$.ExpansionDescriptors
{
    public class SelectExpandItemQueryFunctionDescriptor
    {
        public SortCollectionDescriptor SortCollection { get; set; }
    }
}
