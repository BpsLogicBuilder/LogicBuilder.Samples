﻿namespace $safeprojectname$.Responses
{
    public class ErrorResponse : BaseResponse
    {
    }
}
