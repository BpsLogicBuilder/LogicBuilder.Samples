﻿using $ext_safeprojectname$.Domain;

namespace $safeprojectname$.Requests
{
    public class DeleteEntityRequest : BaseRequest
    {
        public EntityModelBase Entity { get; set; }
    }
}
