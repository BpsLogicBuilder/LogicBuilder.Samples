﻿namespace $safeprojectname$.Requests
{
    public abstract class BaseRequest
    {
    }
}
