﻿using $ext_safeprojectname$.Common.Configuration.ExpansionDescriptors;
using $ext_safeprojectname$.Common.Configuration.ExpressionDescriptors;

namespace $safeprojectname$.Requests
{
    public class GetTypedListRequest : BaseRequest
    {
        public SelectorLambdaOperatorDescriptor Selector { get; set; }
        public SelectExpandDefinitionDescriptor SelectExpandDefinition { get; set; }
        public string ModelType { get; set; }
        public string DataType { get; set; }
        public string ModelReturnType { get; set; }
        public string DataReturnType { get; set; }
    }
}
