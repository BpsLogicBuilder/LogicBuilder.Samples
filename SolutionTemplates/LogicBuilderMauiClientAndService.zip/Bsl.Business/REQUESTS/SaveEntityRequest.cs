﻿using $ext_safeprojectname$.Domain;

namespace $safeprojectname$.Requests
{
    public class SaveEntityRequest : BaseRequest
    {
        public EntityModelBase Entity { get; set; }
    }
}
