﻿using LogicBuilder.EntityFrameworkCore.SqlServer.Crud.DataStores;

namespace $safeprojectname$
{
    public interface IMyStore : IStore
    {
    }
}
