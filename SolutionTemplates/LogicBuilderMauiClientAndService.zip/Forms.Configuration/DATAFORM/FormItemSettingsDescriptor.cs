﻿namespace $safeprojectname$.DataForm
{
    public abstract class FormItemSettingsDescriptor
    {
        abstract public AbstractControlEnumDescriptor AbstractControlType { get; }
    }
}
