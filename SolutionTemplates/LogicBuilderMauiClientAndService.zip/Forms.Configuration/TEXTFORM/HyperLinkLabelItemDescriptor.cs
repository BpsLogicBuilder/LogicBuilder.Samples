﻿namespace $safeprojectname$.TextForm
{
    public class HyperLinkLabelItemDescriptor : LabelItemDescriptorBase
    {
        public string Text { get; set; }
        public string Url { get; set; }
    }
}
