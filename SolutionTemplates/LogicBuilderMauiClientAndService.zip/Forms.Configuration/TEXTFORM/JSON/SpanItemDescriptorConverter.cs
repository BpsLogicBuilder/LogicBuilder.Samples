﻿using $ext_safeprojectname$.Utils;

namespace $safeprojectname$.TextForm.Json
{
    public class SpanItemDescriptorConverter : JsonTypeConverter<SpanItemDescriptorBase>
    {
        public override string TypePropertyName => "TypeString";
    }
}
