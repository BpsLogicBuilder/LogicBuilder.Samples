﻿using $safeprojectname$.TextForm.Json;
using System.Text.Json.Serialization;

namespace $safeprojectname$.TextForm
{
    [JsonConverter(typeof(SpanItemDescriptorConverter))]
    public abstract class SpanItemDescriptorBase
    {
        public string TypeString => this.GetType().AssemblyQualifiedName;
    }
}
