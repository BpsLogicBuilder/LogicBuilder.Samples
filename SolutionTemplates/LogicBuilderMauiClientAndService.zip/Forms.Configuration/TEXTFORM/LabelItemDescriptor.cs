﻿namespace $safeprojectname$.TextForm
{
    public class LabelItemDescriptor : LabelItemDescriptorBase
    {
        public string Text { get; set; }
    }
}
