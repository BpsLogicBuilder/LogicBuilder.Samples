﻿namespace $safeprojectname$.TextForm
{
    public class HyperLinkSpanItemDescriptor : SpanItemDescriptorBase
    {
        public string Text { get; set; }
        public string Url { get; set; }
    }
}
