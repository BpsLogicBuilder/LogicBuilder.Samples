﻿using System.Collections.Generic;

namespace $safeprojectname$.TextForm
{
    public class TextFormSettingsDescriptor
    {
        public string Title { get; set; }
        public List<TextGroupDescriptor> TextGroups { get; set; }
    }
}
