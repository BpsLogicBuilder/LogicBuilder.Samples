﻿using System.Collections.Generic;

namespace $safeprojectname$.Navigation
{
    public class NavigationBarDescriptor
    {
        public string BrandText { get; set; }
        public string CurrentModule { get; set; }
        public List<NavigationMenuItemDescriptor> MenuItems { get; set; }
    }
}
