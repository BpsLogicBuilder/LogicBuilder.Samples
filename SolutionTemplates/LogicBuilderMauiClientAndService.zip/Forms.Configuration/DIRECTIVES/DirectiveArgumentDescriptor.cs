﻿namespace $safeprojectname$.Directives
{
    public class DirectiveArgumentDescriptor
    {
        public string Name { get; set; }
        public object Value { get; set; }
        public string Type { get; set; }
    }
}
