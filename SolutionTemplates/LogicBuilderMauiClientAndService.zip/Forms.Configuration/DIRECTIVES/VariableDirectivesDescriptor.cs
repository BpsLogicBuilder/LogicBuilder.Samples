﻿using System.Collections.Generic;

namespace $safeprojectname$.Directives
{
    public class VariableDirectivesDescriptor
    {
        public string Field { get; set; }
        public List<DirectiveDescriptor> ConditionalDirectives { get; set; }
    }
}
