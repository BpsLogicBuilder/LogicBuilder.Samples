﻿using $ext_safeprojectname$.Common.Configuration.ExpressionDescriptors;
using $safeprojectname$.Bindings;
using System.Collections.Generic;

namespace $safeprojectname$.ListForm
{
    public class ListFormSettingsDescriptor
    {
        public string Title { get; set; }
        public string ModelType { get; set; }
        public string LoadingIndicatorText { get; set; }
        public string ItemTemplateName { get; set; }
        public Dictionary<string, ItemBindingDescriptor> Bindings { get; set; }
        public SelectorLambdaOperatorDescriptor FieldsSelector { get; set; }
        public RequestDetailsDescriptor RequestDetails { get; set; }
    }
}
