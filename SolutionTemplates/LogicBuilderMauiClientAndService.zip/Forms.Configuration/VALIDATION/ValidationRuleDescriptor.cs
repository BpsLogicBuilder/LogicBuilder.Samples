﻿namespace $safeprojectname$.Validation
{
    public class ValidationRuleDescriptor
    {
        public string ClassName { get; set; }
        public string Message { get; set; }
    }
}
