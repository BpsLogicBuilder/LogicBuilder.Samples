﻿namespace $safeprojectname$.SearchForm
{
    public class SearchFilterDescriptor : SearchFilterDescriptorBase
    {
        public string Field { get; set; }
    }
}
