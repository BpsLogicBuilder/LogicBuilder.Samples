﻿using System.Collections.Generic;

namespace $safeprojectname$.SearchForm
{
    public class SearchFilterGroupDescriptor : SearchFilterDescriptorBase
    {
        public ICollection<SearchFilterDescriptorBase> Filters { get; set; }
    }
}
