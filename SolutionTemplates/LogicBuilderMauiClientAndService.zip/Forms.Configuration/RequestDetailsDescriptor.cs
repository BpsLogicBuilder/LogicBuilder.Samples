﻿namespace $safeprojectname$
{
    public class RequestDetailsDescriptor
    {
        public string ModelType { get; set; }
        public string DataType { get; set; }
        public string ModelReturnType { get; set; }
        public string DataReturnType { get; set; }
        public string DataSourceUrl { get; set; }
    }
}
