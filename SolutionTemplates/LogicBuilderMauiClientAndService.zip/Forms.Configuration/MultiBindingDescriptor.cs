﻿using System.Collections.Generic;

namespace $safeprojectname$
{
    public class MultiBindingDescriptor
    {
        public string StringFormat { get; set; }
        public List<string> Fields { get; set; }
    }
}
