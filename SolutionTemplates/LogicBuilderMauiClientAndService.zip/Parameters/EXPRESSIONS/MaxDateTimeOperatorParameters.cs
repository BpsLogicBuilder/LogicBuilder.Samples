﻿namespace $safeprojectname$.Expressions
{
    public class MaxDateTimeOperatorParameters : IExpressionParameter
    {
		public MaxDateTimeOperatorParameters()
		{
		}
    }
}