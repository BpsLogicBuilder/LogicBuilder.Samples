﻿using AutoMapper;
using AutoMapper.Extensions.ExpressionMapping;
using $ext_safeprojectname$.AutoMapperProfiles;
using $ext_safeprojectname$.Bsl.Business.Requests;
using $ext_safeprojectname$.Bsl.Business.Responses;
using $ext_safeprojectname$.Bsl.Flow.Cache;
using $ext_safeprojectname$.BSL.AutoMapperProfiles;
using $ext_safeprojectname$.Contexts;
using $ext_safeprojectname$.Data.Entities;
using $ext_safeprojectname$.Domain.Entities;
using $ext_safeprojectname$.Repositories;
using $ext_safeprojectname$.Stores;
using LogicBuilder.RulesDirector;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;
using Xunit.Abstractions;

namespace $safeprojectname$.Rules
{
    public class SavePersonTest
    {
        public SavePersonTest(ITestOutputHelper output)
        {
            this.output = output;
            Initialize();
        }

        [Fact]
        public void SaveValidPersonRequest()
        {
            //arrange
            IFlowManager flowManager = serviceProvider.GetRequiredService<IFlowManager>();
            var person = flowManager.MyRepository.GetAsync<PersonModel, Person>
            (
                s => s.FullName == "Carson Alexander"
            ).Result.Single();
            person.FirstName = "First";
            person.EntityState = LogicBuilder.Domain.EntityStateType.Modified;
            flowManager.FlowDataCache.Request = new SaveEntityRequest { Entity = person };

            //act
            System.Diagnostics.Stopwatch stopWatch = System.Diagnostics.Stopwatch.StartNew();
            flowManager.Start("saveperson");
            stopWatch.Stop();
            this.output.WriteLine("Saving valid person = {0}", stopWatch.Elapsed.TotalMilliseconds);

            //assert
            Assert.True(flowManager.FlowDataCache.Response.Success);
            Assert.Equal("First", ((PersonModel)((SaveEntityResponse)flowManager.FlowDataCache.Response).Entity).FirstName);
        }

        [Fact]
        public void SaveInvalidPersonRequest()
        {
            //arrange
            IFlowManager flowManager = serviceProvider.GetRequiredService<IFlowManager>();
            var person = flowManager.MyRepository.GetAsync<PersonModel, Person>
            (
                s => s.FullName == "Carson Alexander"
            ).Result.Single();
            person.FirstName = "";
            person.LastName = "";
            person.DateOfBirth = default;
            person.EntityState = LogicBuilder.Domain.EntityStateType.Modified;
            flowManager.FlowDataCache.Request = new SaveEntityRequest { Entity = person };

            //act
            System.Diagnostics.Stopwatch stopWatch = System.Diagnostics.Stopwatch.StartNew();
            flowManager.Start("saveperson");
            stopWatch.Stop();
            this.output.WriteLine("Saving invalid person = {0}", stopWatch.Elapsed.TotalMilliseconds);

            //assert
            Assert.False(flowManager.FlowDataCache.Response.Success);
            Assert.Equal(3, flowManager.FlowDataCache.Response.ErrorMessages.Count);
        }

        #region Fields
        private IServiceProvider serviceProvider;
        private readonly ITestOutputHelper output;
        #endregion Fields

        #region Helpers
        static MapperConfiguration MapperConfiguration;
        private void Initialize()
        {
            if (MapperConfiguration == null)
            {
                MapperConfiguration = new MapperConfiguration(cfg =>
                {
                    cfg.AddExpressionMapping();

                    cfg.AddProfile<ParameterToDescriptorMappingProfile>();
                    cfg.AddProfile<DescriptorToOperatorMappingProfile>();
                    cfg.AddProfile<MyProfile>();
                    cfg.AddProfile<ExpansionParameterToDescriptorMappingProfile>();
                    cfg.AddProfile<ExpansionDescriptorToOperatorMappingProfile>();
                });
            }
            MapperConfiguration.AssertConfigurationIsValid();
            serviceProvider = new ServiceCollection()
                .AddDbContext<MyContext>
                (
                    options => options.UseSqlServer
                    (
                        @"Server=(localdb)\mssqllocaldb;Database=SavePersonTest;ConnectRetryCount=0"
                    ),
                    ServiceLifetime.Transient
                )
                .AddLogging
                (
                    loggingBuilder =>
                    {
                        loggingBuilder.ClearProviders();
                        loggingBuilder.Services.AddSingleton<ILoggerProvider>
                        (
                            serviceProvider => new XUnitLoggerProvider(this.output)
                        );
                        loggingBuilder.AddFilter<XUnitLoggerProvider>("*", LogLevel.None);
                        loggingBuilder.AddFilter<XUnitLoggerProvider>("$ext_safeprojectname$.Bsl.Flow", LogLevel.Trace);
                    }
                )
                .AddTransient<IMyStore, MyStore>()
                .AddTransient<IMyRepository, MyRepository>()
                .AddSingleton<AutoMapper.IConfigurationProvider>
                (
                    MapperConfiguration
                )
                .AddTransient<IMapper>(sp => new Mapper(sp.GetRequiredService<AutoMapper.IConfigurationProvider>(), sp.GetService))
                .AddTransient<IFlowManager, FlowManager>()
                .AddTransient<FlowActivityFactory, FlowActivityFactory>()
                .AddTransient<DirectorFactory, DirectorFactory>()
                .AddTransient<ICustomActions, CustomActions>()
                .AddSingleton<FlowDataCache, FlowDataCache>()
                .AddSingleton<Progress, Progress>()
                .AddSingleton<IRulesCache>(sp =>
                {
                    return Bsl.Flow.Rules.RulesService.LoadRules().GetAwaiter().GetResult();
                })
                .BuildServiceProvider();

            ReCreateDataBase(serviceProvider.GetRequiredService<MyContext>());
            DatabaseSeeder.Seed_Database(serviceProvider.GetRequiredService<IMyRepository>()).Wait();
        }

        private static void ReCreateDataBase(MyContext context)
        {
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();
        }
        #endregion Helpers
    }
}
