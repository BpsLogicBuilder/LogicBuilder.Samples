﻿using $ext_safeprojectname$.Data.Entities;
using $ext_safeprojectname$.Domain.Entities;
using $ext_safeprojectname$.Repositories;
using System;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    internal static class DatabaseSeeder
    {
        internal static async Task Seed_Database(IMyRepository repository)
        {
            if ((await repository.CountAsync<PersonModel, Person>()) > 0)
                return;//database has been seeded

            PersonModel[] persons = new PersonModel[]
            {
                new PersonModel
                {
                    EntityState =  LogicBuilder.Domain.EntityStateType.Added,
                    FirstName = "Carson",   LastName = "Alexander",
                    DateOfBirth = DateTime.Parse("2010-09-01")
                },
                new PersonModel
                {
                    EntityState =  LogicBuilder.Domain.EntityStateType.Added,
                    FirstName = "Meredith", LastName = "Alonso",
                    DateOfBirth = DateTime.Parse("2012-09-01")
                },
                new PersonModel
                {
                    EntityState =  LogicBuilder.Domain.EntityStateType.Added,
                    FirstName = "Arturo",   LastName = "Anand",
                    DateOfBirth = DateTime.Parse("2013-09-01")
                },
                new PersonModel
                {
                    EntityState =  LogicBuilder.Domain.EntityStateType.Added,
                    FirstName = "Gytis",    LastName = "Barzdukas",
                    DateOfBirth = DateTime.Parse("2012-09-01")
                },
                new PersonModel
                {
                    EntityState =  LogicBuilder.Domain.EntityStateType.Added,
                    FirstName = "Yan",      LastName = "Li",
                    DateOfBirth = DateTime.Parse("2012-09-01")
                },
                new PersonModel
                {
                    EntityState =  LogicBuilder.Domain.EntityStateType.Added,
                    FirstName = "Peggy",    LastName = "Justice",
                    DateOfBirth = DateTime.Parse("2011-09-01")
                },
                new PersonModel
                {
                    EntityState =  LogicBuilder.Domain.EntityStateType.Added,
                    FirstName = "Laura",    LastName = "Norman",
                    DateOfBirth = DateTime.Parse("2013-09-01")
                },
                new PersonModel
                {
                    EntityState = LogicBuilder.Domain.EntityStateType.Added,
                    FirstName = "Nino",     LastName = "Olivetto",
                    DateOfBirth = DateTime.Parse("2005-09-01")
                },
                new PersonModel
                {
                    EntityState = LogicBuilder.Domain.EntityStateType.Added,
                    FirstName = "Tom",
                    LastName = "Spratt",
                    DateOfBirth = DateTime.Parse("2010-09-01")
                },
                new PersonModel
                {
                    EntityState = LogicBuilder.Domain.EntityStateType.Added,
                    FirstName = "Billie",
                    LastName = "Spratt",
                    DateOfBirth = DateTime.Parse("2010-09-01")
                },
                new PersonModel
                {
                    EntityState = LogicBuilder.Domain.EntityStateType.Added,
                    FirstName = "Jackson",
                    LastName = "Spratt",
                    DateOfBirth = DateTime.Parse("2017-09-01")
                }
            };

            await repository.SaveGraphsAsync<PersonModel, Person>(persons);
        }
    }
}
