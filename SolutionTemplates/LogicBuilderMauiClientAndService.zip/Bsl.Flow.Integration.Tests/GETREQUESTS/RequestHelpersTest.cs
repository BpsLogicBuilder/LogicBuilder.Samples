﻿using AutoMapper;
using AutoMapper.Extensions.ExpressionMapping;
using $ext_safeprojectname$.AutoMapperProfiles;
using $ext_safeprojectname$.Common.Configuration.ExpressionDescriptors;
using $ext_safeprojectname$.Common.Utils;
using $ext_safeprojectname$.Bsl.Utils;
using $ext_safeprojectname$.BSL.AutoMapperProfiles;
using $ext_safeprojectname$.Contexts;
using $ext_safeprojectname$.Data.Entities;
using $ext_safeprojectname$.Domain.Entities;
using $ext_safeprojectname$.Repositories;
using $ext_safeprojectname$.Stores;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using Xunit;

namespace $safeprojectname$.GetRequests
{
    public class RequestHelpersTest
    {
        public RequestHelpersTest()
        {
            Initialize();
        }

        #region Fields
        private IServiceProvider serviceProvider;
        #endregion Fields

        [Fact]
        public void Select_Persons_In_Ascending_Order_As_PersonModel_Type()
        {
            //arrange
            var selectorLambdaOperatorDescriptor = new SelectorLambdaOperatorDescriptor
            {
                Selector = GetPersonsBodyForPersonModelType(),
                SourceElementType = typeof(IQueryable<PersonModel>).AssemblyQualifiedName,
                ParameterName = "q",
                BodyType = typeof(IEnumerable<PersonModel>).AssemblyQualifiedName
            };

            IMapper mapper = serviceProvider.GetRequiredService<IMapper>();
            IMyRepository repository = serviceProvider.GetRequiredService<IMyRepository>();

            //act
            var expression = mapper.MapToOperator(selectorLambdaOperatorDescriptor).Build();
            var list = RequestHelpers.GetList<PersonModel, Person, IEnumerable<PersonModel>, IEnumerable<Person>>
            (
                new Business.Requests.GetTypedListRequest
                {
                    Selector = selectorLambdaOperatorDescriptor,
                    ModelType = typeof(PersonModel).AssemblyQualifiedName,
                    DataType = typeof(Person).AssemblyQualifiedName,
                    ModelReturnType = typeof(IEnumerable<PersonModel>).AssemblyQualifiedName,
                    DataReturnType = typeof(IEnumerable<Person>).AssemblyQualifiedName
                },
                repository,
                mapper
            ).Result.List.ToList();

            //assert
            AssertFilterStringIsCorrect(expression, "q => Convert(q.OrderBy(d => d.FullName).Take(2))");
            Assert.Equal(2, list.Count);
        }

        [Fact]
        public void Select_Group_Persons_By_EnrollmentDate_Return_EnrollmentDate_With_Count()
        {
            //arrange
            Expression<Func<IQueryable<PersonModel>, IQueryable<LookUpsModel>>> expression1 =
                q => q.GroupBy(item => item.DateOfBirth)
                .OrderBy(group => group.Key)
                .Select
                (
                    sel => new LookUpsModel
                    {
                        DateTimeValue = sel.Key,
                        NumericValue = sel.AsQueryable().Count()
                    }
                );


            //arrange
            var selectorLambdaOperatorDescriptor = new SelectorLambdaOperatorDescriptor
            {
                Selector = GetAboutBody(),
                SourceElementType = typeof(IQueryable<PersonModel>).AssemblyQualifiedName,
                ParameterName = "q",
                BodyType = typeof(IQueryable<LookUpsModel>).AssemblyQualifiedName
            };
            IMapper mapper = serviceProvider.GetRequiredService<IMapper>();
            IMyRepository repository = serviceProvider.GetRequiredService<IMyRepository>();

            //act
            var expression = mapper.MapToOperator(selectorLambdaOperatorDescriptor).Build();
            var list = RequestHelpers.GetList
            (
                new Business.Requests.GetTypedListRequest
                {
                    Selector = selectorLambdaOperatorDescriptor,
                    ModelType = typeof(PersonModel).AssemblyQualifiedName,
                    DataType = typeof(Person).AssemblyQualifiedName,
                    ModelReturnType = typeof(IQueryable<LookUpsModel>).AssemblyQualifiedName,
                    DataReturnType = typeof(IQueryable<LookUps>).AssemblyQualifiedName
                },
                repository,
                mapper
            ).Result.List.ToList();

            //assert
            AssertFilterStringIsCorrect(expression, "q => q.GroupBy(item => item.DateOfBirth).OrderByDescending(group => group.Key).Select(sel => new LookUpsModel() {DateTimeValue = sel.Key, NumericValue = Convert(sel.AsQueryable().Count())})");
            Assert.Equal(6, list.Count);
        }

        #region Helpers
        private void AssertFilterStringIsCorrect(Expression expression, string expected)
        {
            AssertStringIsCorrect(ExpressionStringBuilder.ToString(expression));

            void AssertStringIsCorrect(string resultExpression)
                => Assert.True
                (
                    expected == resultExpression,
                    $"Expected expression '{expected}' but the deserializer produced '{resultExpression}'"
                );
        }

        private SelectOperatorDescriptor GetAboutBody()
            => new SelectOperatorDescriptor
            {
                SourceOperand = new OrderByOperatorDescriptor
                {
                    SourceOperand = new GroupByOperatorDescriptor
                    {
                        SourceOperand = new ParameterOperatorDescriptor
                        {
                            ParameterName = "q"
                        },
                        SelectorBody = new MemberSelectorOperatorDescriptor
                        {
                            MemberFullName = "DateOfBirth",
                            SourceOperand = new ParameterOperatorDescriptor
                            {
                                ParameterName = "item"
                            }
                        },
                        SelectorParameterName = "item"
                    },
                    SortDirection = LogicBuilder.Expressions.Utils.Strutures.ListSortDirection.Descending,
                    SelectorBody = new MemberSelectorOperatorDescriptor
                    {
                        MemberFullName = "Key",
                        SourceOperand = new ParameterOperatorDescriptor
                        {
                            ParameterName = "group"
                        }
                    },
                    SelectorParameterName = "group"
                },
                SelectorBody = new MemberInitOperatorDescriptor
                {
                    MemberBindings = new Dictionary<string, OperatorDescriptorBase>
                    {
                        ["DateTimeValue"] = new MemberSelectorOperatorDescriptor
                        {
                            MemberFullName = "Key",
                            SourceOperand = new ParameterOperatorDescriptor
                            {
                                ParameterName = "sel"
                            }
                        },
                        ["NumericValue"] = new ConvertOperatorDescriptor
                        {
                            SourceOperand = new CountOperatorDescriptor
                            {
                                SourceOperand = new AsQueryableOperatorDescriptor()
                                {
                                    SourceOperand = new ParameterOperatorDescriptor
                                    {
                                        ParameterName = "sel"
                                    }
                                }
                            },
                            Type = typeof(double?).FullName
                        }
                    },
                    NewType = typeof(LookUpsModel).AssemblyQualifiedName
                },
                SelectorParameterName = "sel"
            };

        private TakeOperatorDescriptor GetPersonsBodyForPersonModelType()
            => new TakeOperatorDescriptor
            {
                SourceOperand = new OrderByOperatorDescriptor
                {
                    SourceOperand = new ParameterOperatorDescriptor { ParameterName = "q" },
                    SelectorBody = new MemberSelectorOperatorDescriptor
                    {
                        SourceOperand = new ParameterOperatorDescriptor { ParameterName = "d" },
                        MemberFullName = "FullName"
                    },
                    SortDirection = LogicBuilder.Expressions.Utils.Strutures.ListSortDirection.Ascending,
                    SelectorParameterName = "d"
                },
                Count = 2
            };

        static MapperConfiguration MapperConfiguration;

        private void Initialize()
        {
            if (MapperConfiguration == null)
            {
                MapperConfiguration = new MapperConfiguration(cfg =>
                {
                    cfg.AddExpressionMapping();

                    cfg.AddProfile<DescriptorToOperatorMappingProfile>();
                    cfg.AddProfile<MyProfile>();
                    cfg.AddProfile<ExpansionDescriptorToOperatorMappingProfile>();
                });
            }
            MapperConfiguration.AssertConfigurationIsValid();
            serviceProvider = new ServiceCollection()
                .AddDbContext<MyContext>
                (
                    options => options.UseSqlServer
                    (
                        @"Server=(localdb)\mssqllocaldb;Database=RequestHelpersTest;ConnectRetryCount=0"
                    ),
            ServiceLifetime.Transient
                )
                .AddTransient<IMyStore, MyStore>()
                .AddTransient<IMyRepository, MyRepository>()
                .AddSingleton<AutoMapper.IConfigurationProvider>
                (
                    MapperConfiguration
                )
                .AddTransient<IMapper>(sp => new Mapper(sp.GetRequiredService<AutoMapper.IConfigurationProvider>(), sp.GetService))
                .BuildServiceProvider();

            MyContext context = serviceProvider.GetRequiredService<MyContext>();
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

            DatabaseSeeder.Seed_Database(serviceProvider.GetRequiredService<IMyRepository>()).Wait();
        }
        #endregion Helpers
    }
}
