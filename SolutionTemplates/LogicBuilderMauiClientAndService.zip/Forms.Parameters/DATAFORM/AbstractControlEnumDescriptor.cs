﻿namespace $safeprojectname$.DataForm
{
    public enum AbstractControlEnumDescriptor
    {
		FormControl,
		MultiSelectFormControl,
		FormGroup,
		FormGroupArray,
		GroupBox
	}
}