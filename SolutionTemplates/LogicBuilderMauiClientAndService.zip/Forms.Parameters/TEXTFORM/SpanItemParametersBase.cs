﻿using LogicBuilder.Attributes;

namespace $safeprojectname$.TextForm
{
    abstract public class SpanItemParametersBase
    {

    }
}