﻿using LogicBuilder.Attributes;

namespace $safeprojectname$.TextForm
{
    public class SpanItemParameters : SpanItemParametersBase
    {
		public SpanItemParameters
		(
			[Comments("Span text.")]
			string text
		)
		{
			Text = text;
		}

		public string Text { get; set; }
    }
}