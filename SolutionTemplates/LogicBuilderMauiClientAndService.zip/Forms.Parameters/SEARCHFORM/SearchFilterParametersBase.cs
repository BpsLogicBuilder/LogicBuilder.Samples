﻿using LogicBuilder.Attributes;

namespace $safeprojectname$.SearchForm
{
    abstract public class SearchFilterParametersBase
    {

    }
}