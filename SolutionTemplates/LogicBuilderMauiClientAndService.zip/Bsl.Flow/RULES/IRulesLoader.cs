﻿using $ext_safeprojectname$.Domain.Entities;
using System.Threading.Tasks;

namespace $safeprojectname$.Rules
{
    public interface IRulesLoader
    {
        Task LoadRulesOnStartUp(RulesModuleModel modules, RulesCache cache);
    }
}
