﻿using AutoMapper;
using $ext_safeprojectname$.BSL.AutoMapperProfiles;
using $ext_safeprojectname$.Contexts;
using $ext_safeprojectname$.Data.Entities;
using $ext_safeprojectname$.Domain;
using $ext_safeprojectname$.Domain.Entities;
using $ext_safeprojectname$.Repositories;
using $ext_safeprojectname$.Stores;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    class Program
    {
        static void Main(string[] args)
        {
            IConfigurationRoot config = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .Build();

            IServiceProvider serviceProvider = new ServiceCollection().AddDbContext<MyContext>(options =>
                options.UseSqlServer(config.GetConnectionString("DefaultConnection")), ServiceLifetime.Transient)
                .AddTransient<IMyStore, MyStore>()
                .AddTransient<IMyRepository, MyRepository>()
                .AddSingleton<AutoMapper.IConfigurationProvider>(new MapperConfiguration(cfg => cfg.AddMaps(typeof(MyProfile).GetTypeInfo().Assembly)))
                .AddTransient<IMapper>(sp => new Mapper(sp.GetRequiredService<AutoMapper.IConfigurationProvider>(), sp.GetService))
                .BuildServiceProvider();

            MyContext context = serviceProvider.GetRequiredService<MyContext>();
            context.Database.EnsureCreated();

            Task.Run(async () => await Seed_Database(serviceProvider.GetRequiredService<IMyRepository>())).Wait();
        }

        private static async Task Seed_Database(IMyRepository repository)
        {
            if ((await repository.CountAsync<PersonModel, Person>()) > 0)
                return;//database has been seeded

            PersonModel[] persons = new PersonModel[]
            {
                new PersonModel
                {
                    EntityState =  LogicBuilder.Domain.EntityStateType.Added,
                    FirstName = "Carson",   LastName = "Alexander",
                    DateOfBirth = DateTime.Parse("2010-09-01")
                },
                new PersonModel
                {
                    EntityState =  LogicBuilder.Domain.EntityStateType.Added,
                    FirstName = "Meredith", LastName = "Alonso",
                    DateOfBirth = DateTime.Parse("2012-09-01")
                },
                new PersonModel
                {
                    EntityState =  LogicBuilder.Domain.EntityStateType.Added,
                    FirstName = "Arturo",   LastName = "Anand",
                    DateOfBirth = DateTime.Parse("2013-09-01")
                },
                new PersonModel
                {
                    EntityState =  LogicBuilder.Domain.EntityStateType.Added,
                    FirstName = "Gytis",    LastName = "Barzdukas",
                    DateOfBirth = DateTime.Parse("2012-09-01")
                },
                new PersonModel
                {
                    EntityState =  LogicBuilder.Domain.EntityStateType.Added,
                    FirstName = "Yan",      LastName = "Li",
                    DateOfBirth = DateTime.Parse("2012-09-01")
                },
                new PersonModel
                {
                    EntityState =  LogicBuilder.Domain.EntityStateType.Added,
                    FirstName = "Peggy",    LastName = "Justice",
                    DateOfBirth = DateTime.Parse("2011-09-01")
                },
                new PersonModel
                {
                    EntityState =  LogicBuilder.Domain.EntityStateType.Added,
                    FirstName = "Laura",    LastName = "Norman",
                    DateOfBirth = DateTime.Parse("2013-09-01")
                },
                new PersonModel
                {
                    EntityState = LogicBuilder.Domain.EntityStateType.Added,
                    FirstName = "Nino",     LastName = "Olivetto",
                    DateOfBirth = DateTime.Parse("2005-09-01")
                },
                new PersonModel
                {
                    EntityState = LogicBuilder.Domain.EntityStateType.Added,
                    FirstName = "Tom",
                    LastName = "Spratt",
                    DateOfBirth = DateTime.Parse("2010-09-01")
                },
                new PersonModel
                {
                    EntityState = LogicBuilder.Domain.EntityStateType.Added,
                    FirstName = "Billie",
                    LastName = "Spratt",
                    DateOfBirth = DateTime.Parse("2010-09-01")
                },
                new PersonModel
                {
                    EntityState = LogicBuilder.Domain.EntityStateType.Added,
                    FirstName = "Jackson",
                    LastName = "Spratt",
                    DateOfBirth = DateTime.Parse("2017-09-01")
                }
            };

            await repository.SaveGraphsAsync<PersonModel, Person>(persons);
        }
    }
}