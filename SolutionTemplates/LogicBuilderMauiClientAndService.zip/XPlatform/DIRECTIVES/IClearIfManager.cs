﻿using System;

namespace $safeprojectname$.Directives
{
    public interface IClearIfManager : IDisposable
    {
    }
}
