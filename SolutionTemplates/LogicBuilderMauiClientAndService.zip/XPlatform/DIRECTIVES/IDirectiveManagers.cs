﻿using System;

namespace $safeprojectname$.Directives
{
    public interface IDirectiveManagers : IDisposable
    {
    }
}
