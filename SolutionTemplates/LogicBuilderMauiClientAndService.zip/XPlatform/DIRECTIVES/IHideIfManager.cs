﻿using System;

namespace $safeprojectname$.Directives
{
    public interface IHideIfManager : IDisposable
    {
    }
}
