﻿using System;

namespace $safeprojectname$.Directives
{
    public interface IReadOnlyDirectiveManagers : IDisposable
    {
    }
}
