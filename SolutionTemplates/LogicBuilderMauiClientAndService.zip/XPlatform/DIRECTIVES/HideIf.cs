﻿namespace $safeprojectname$.Directives
{
    public class HideIf<T> : ConditionBase<T>
    {
    }
}
