﻿namespace $safeprojectname$.Directives
{
    public class ClearIf<T> : ConditionBase<T>
    {
    }
}
