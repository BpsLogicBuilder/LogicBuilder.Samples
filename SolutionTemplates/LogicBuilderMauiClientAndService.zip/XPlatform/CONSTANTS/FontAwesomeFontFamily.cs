﻿namespace $safeprojectname$.Constants
{
    public struct FontAwesomeFontFamily
    {
        public const string AndroidSolid = "FontAwesome5Solid900.otf#Regular";
        public const string iOSSolid = "Font Awesome 5 Free Solid";
        public const string MacCatalystSolid = "Font Awesome 5 Free Solid";
        public const string TizenSolid = "";
        public const string WinUISolid = "/Assets/FontAwesome5Solid900.otf#Font Awesome 5 Free";
    }
}
