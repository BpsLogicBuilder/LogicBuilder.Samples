﻿using $ext_safeprojectname$.XPlatform.Utils;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using Xunit;

namespace $safeprojectname$
{
    public class DictionaryComparisonTests
    {
        public DictionaryComparisonTests()
        {
            Initialize();
        }

        #region Fields
        private Dictionary<string, object?> first;
        private Dictionary<string, object?> second;
        #endregion Fields

        [Fact]
        public void ShouldReturnTrueForMatchingLists()
        {
            Dictionary<string, object?> first = new()
            {
                ["list"] = new List<int> { 1, 2, 3 }
            };

            Dictionary<string, object?> second = new()
            {
                ["list"] = new List<int> { 1, 2, 3 }
            };

            Assert.True(new DictionaryComparer().Equals(first, second));
        }

        [Fact]
        public void ShouldReturnFalseForListsOutOfOrder()
        {
            Dictionary<string, object?> first = new()
            {
                ["list"] = new List<int> { 1, 2, 3 }
            };

            Dictionary<string, object?> second = new()
            {
                ["list"] = new List<int> { 1, 3, 2 }
            };

            Assert.False(new DictionaryComparer().Equals(first, second));
        }

        [Fact]
        public void ShouldReturnTrueIfAllFieldsMatch()
        {
            Assert.True(new DictionaryComparer().Equals(first, second));
        }

        [Fact]
        public void ShouldReturnFalseValuesDoNotMatch()
        {
            first["ID"] = 3;
            second["ID"] = 4;
            Assert.False(new DictionaryComparer().Equals(first, second));
        }

        [MemberNotNull(nameof(first), nameof(second))]
        private void Initialize()
        {
            first = new Dictionary<string, object?>
            {
                ["ID"] = 3,
                ["FirstName"] = "John",
                ["LastName"] = "Smith",
                ["DateOfBirth"] = new DateTime(2021, 5, 20)
            };

            second = new Dictionary<string, object?>
            {
                ["ID"] = 3,
                ["FirstName"] = "John",
                ["LastName"] = "Smith",
                ["DateOfBirth"] = new DateTime(2021, 5, 20)
            };
        }
    }
}
