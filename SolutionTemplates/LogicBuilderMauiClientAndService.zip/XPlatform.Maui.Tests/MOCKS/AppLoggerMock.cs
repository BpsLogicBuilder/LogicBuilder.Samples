﻿using $ext_safeprojectname$.XPlatform.Flow;
using System;

namespace $safeprojectname$.Mocks
{
    public class AppLoggerMock : IAppLogger
    {
        public void LogMessage(string group, string message)
        {
        }
    }
}
