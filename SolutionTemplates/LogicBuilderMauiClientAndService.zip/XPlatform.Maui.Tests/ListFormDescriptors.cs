﻿using $ext_safeprojectname$.Common.Configuration.ExpressionDescriptors;
using $ext_safeprojectname$.Data.Entities;
using $ext_safeprojectname$.Domain.Entities;
using $ext_safeprojectname$.Forms.Configuration;
using $ext_safeprojectname$.Forms.Configuration.Bindings;
using $ext_safeprojectname$.Forms.Configuration.ListForm;
using System.Collections.Generic;
using System.Linq;

namespace $safeprojectname$
{
    internal static class ListFormDescriptors
    {
        internal static ListFormSettingsDescriptor AboutForm = new()
        {
            Title = "About",
            ModelType = typeof(LookUpsModel).AssemblyQualifiedName,
            LoadingIndicatorText = "Loading ...",
            ItemTemplateName = "TextDetailTemplate",
            Bindings = new List<ItemBindingDescriptor>
            {
                new TextItemBindingDescriptor
                {
                    Name = "Text",
                    Property = "DateTimeValue",
                    Title = "DateTimeValue",
                    StringFormat = "Enrollment Date: {0:MM/dd/yyyy}",
                    TextTemplate = new TextFieldTemplateDescriptor
                    {
                        TemplateName = "TextTemplate"
                    }
                }
            }.ToDictionary(i => i.Name),
            FieldsSelector = new SelectorLambdaOperatorDescriptor
            {
                Selector = new SelectOperatorDescriptor
                {
                    SourceOperand = new OrderByOperatorDescriptor
                    {
                        SourceOperand = new GroupByOperatorDescriptor
                        {
                            SourceOperand = new ParameterOperatorDescriptor
                            {
                                ParameterName = "q"
                            },
                            SelectorBody = new MemberSelectorOperatorDescriptor
                            {
                                MemberFullName = "DateOfBirth",
                                SourceOperand = new ParameterOperatorDescriptor
                                {
                                    ParameterName = "item"
                                }
                            },
                            SelectorParameterName = "item"
                        },
                        SortDirection = LogicBuilder.Expressions.Utils.Strutures.ListSortDirection.Descending,
                        SelectorBody = new MemberSelectorOperatorDescriptor
                        {
                            MemberFullName = "Key",
                            SourceOperand = new ParameterOperatorDescriptor
                            {
                                ParameterName = "group"
                            }
                        },
                        SelectorParameterName = "group"
                    },
                    SelectorBody = new MemberInitOperatorDescriptor
                    {
                        MemberBindings = new Dictionary<string, OperatorDescriptorBase>
                        {
                            ["DateTimeValue"] = new MemberSelectorOperatorDescriptor
                            {
                                MemberFullName = "Key",
                                SourceOperand = new ParameterOperatorDescriptor
                                {
                                    ParameterName = "sel"
                                }
                            },
                            ["NumericValue"] = new ConvertOperatorDescriptor
                            {
                                SourceOperand = new CountOperatorDescriptor
                                {
                                    SourceOperand = new AsQueryableOperatorDescriptor()
                                    {
                                        SourceOperand = new ParameterOperatorDescriptor
                                        {
                                            ParameterName = "sel"
                                        }
                                    }
                                },
                                Type = typeof(double?).FullName
                            }
                        },
                        NewType = typeof(LookUpsModel).AssemblyQualifiedName
                    },
                    SelectorParameterName = "sel"
                },
                SourceElementType = typeof(IQueryable<PersonModel>).AssemblyQualifiedName,
                ParameterName = "$it",
                BodyType = typeof(IQueryable<LookUpsModel>).AssemblyQualifiedName
            },
            RequestDetails = new RequestDetailsDescriptor
            {
                DataSourceUrl = "api/List/GetList",
                ModelType = typeof(PersonModel).AssemblyQualifiedName,
                DataType = typeof(Person).AssemblyQualifiedName,
                ModelReturnType = typeof(IQueryable<LookUpsModel>).AssemblyQualifiedName,
                DataReturnType = typeof(IQueryable<LookUps>).AssemblyQualifiedName,
            }
        };
    }
}
