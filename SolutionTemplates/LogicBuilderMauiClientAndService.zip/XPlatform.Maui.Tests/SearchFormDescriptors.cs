﻿using $ext_safeprojectname$.Data.Entities;
using $ext_safeprojectname$.Domain.Entities;
using $ext_safeprojectname$.Forms.Configuration;
using $ext_safeprojectname$.Forms.Configuration.Bindings;
using $ext_safeprojectname$.Forms.Configuration.SearchForm;
using System.Collections.Generic;
using System.Linq;

namespace $safeprojectname$
{
    internal static class SearchFormDescriptors
    {
        internal static SearchFormSettingsDescriptor PersonsForm = new()
        {
            Title = "About",
            ModelType = typeof(LookUpsModel).AssemblyQualifiedName,
            LoadingIndicatorText = "Loading ...",
            ItemTemplateName = "TextDetailTemplate",
            CreatePagingSelectorFlowName = "paging_selector_students",
            Bindings = new List<ItemBindingDescriptor>
            {
                new TextItemBindingDescriptor
                {
                    Name = "Text",
                    Property = "DateTimeValue",
                    Title = "DateTimeValue",
                    StringFormat = "Date Of Birth: {0:MM/dd/yyyy}",
                    TextTemplate = new TextFieldTemplateDescriptor
                    {
                        TemplateName = "TextTemplate"
                    }
                }
            }.ToDictionary(i => i.Name),
            RequestDetails = new RequestDetailsDescriptor
            {
                DataSourceUrl = "api/List/GetList",
                ModelType = typeof(PersonModel).AssemblyQualifiedName,
                DataType = typeof(Person).AssemblyQualifiedName,
                ModelReturnType = typeof(IQueryable<LookUpsModel>).AssemblyQualifiedName,
                DataReturnType = typeof(IQueryable<LookUps>).AssemblyQualifiedName,
            }
        };
    }
}
