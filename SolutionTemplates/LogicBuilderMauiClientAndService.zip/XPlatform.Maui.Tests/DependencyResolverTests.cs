﻿using $ext_safeprojectname$.Forms.Configuration.DataForm;
using $ext_safeprojectname$.Forms.Configuration.ListForm;
using $ext_safeprojectname$.Forms.Configuration.SearchForm;
using $ext_safeprojectname$.Forms.Configuration.TextForm;
using $ext_safeprojectname$.XPlatform.Flow.Settings.Screen;
using $safeprojectname$.Helpers;
using $ext_safeprojectname$.XPlatform.ViewModels.DetailForm;
using $ext_safeprojectname$.XPlatform.ViewModels.EditForm;
using $ext_safeprojectname$.XPlatform.ViewModels.ListPage;
using $ext_safeprojectname$.XPlatform.ViewModels.SearchPage;
using $ext_safeprojectname$.XPlatform.ViewModels.TextPage;
using Microsoft.Extensions.DependencyInjection;
using System;
using Xunit;

namespace $safeprojectname$
{
    public class DependencyResolverTests
    {
        public DependencyResolverTests()
        {
            serviceProvider = ServiceProviderHelper.GetServiceProvider();
        }

        #region Fields
        private readonly IServiceProvider serviceProvider;
        #endregion Fields

        [Fact]
        public void CanCreateListPageViewMode()
        {
            ScreenSettingsBase settings = new ScreenSettings<ListFormSettingsDescriptor>(ListFormDescriptors.AboutForm, Descriptors.ButtonDescriptors, ViewType.ListPage);
            Func<ScreenSettingsBase, ListPageViewModelBase> factoryFunc = serviceProvider.GetRequiredService<Func<ScreenSettingsBase, ListPageViewModelBase>>();
            ListPageViewModelBase viewModel = factoryFunc(settings);
            Assert.NotNull(viewModel);
        }

        [Fact]
        public void CanCreateSearchPageViewMode()
        {
            ScreenSettingsBase settings = new ScreenSettings<SearchFormSettingsDescriptor>(SearchFormDescriptors.PersonsForm, Descriptors.ButtonDescriptors, ViewType.SearchPage);
            Func<ScreenSettingsBase, SearchPageViewModelBase> factoryFunc = serviceProvider.GetRequiredService<Func<ScreenSettingsBase, SearchPageViewModelBase>>();
            SearchPageViewModelBase viewModel = factoryFunc(settings);
            Assert.NotNull(viewModel);
        }

        [Fact]
        public void CanCreateTextPageViewMode()
        {
            ScreenSettingsBase settings = new ScreenSettings<TextFormSettingsDescriptor>(TextFormDescriptors.HomePage, Descriptors.ButtonDescriptors, ViewType.TextPage);
            Func<ScreenSettingsBase, TextPageViewModel> factoryFunc = serviceProvider.GetRequiredService<Func<ScreenSettingsBase, TextPageViewModel>>();
            TextPageViewModel viewModel = factoryFunc(settings);
            Assert.NotNull(viewModel);
        }
    }
}
