﻿using $ext_safeprojectname$.Domain;
using LogicBuilder.Attributes;

namespace $safeprojectname$.Responses
{
    public class SaveEntityResponse : BaseResponse
    {
        [AlsoKnownAs("SaveEntityResponse_Entity")]
        public EntityModelBase Entity { get; set; }
    }
}
