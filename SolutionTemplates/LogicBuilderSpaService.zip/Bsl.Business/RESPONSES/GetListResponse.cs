﻿using $ext_safeprojectname$.Domain;
using System.Collections.Generic;

namespace $safeprojectname$.Responses
{
    public class GetListResponse : BaseResponse
    {
        public IEnumerable<EntityModelBase> List { get; set; }
    }
}
