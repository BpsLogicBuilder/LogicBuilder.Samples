﻿namespace $safeprojectname$.Responses
{
    public class DeleteEntityResponse : BaseResponse
    {
    }
}
