﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class NegateOperatorDescriptor : OperatorDescriptorBase
    {
		public OperatorDescriptorBase Operand { get; set; }
    }
}