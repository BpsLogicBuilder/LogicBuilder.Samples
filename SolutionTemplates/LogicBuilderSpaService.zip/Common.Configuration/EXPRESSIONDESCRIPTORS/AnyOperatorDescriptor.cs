﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class AnyOperatorDescriptor : FilterMethodOperatorDescriptorBase
    {

    }
}