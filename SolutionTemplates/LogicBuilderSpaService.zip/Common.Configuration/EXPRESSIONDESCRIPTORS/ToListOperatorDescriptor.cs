﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class ToListOperatorDescriptor : OperatorDescriptorBase
    {
		public OperatorDescriptorBase SourceOperand { get; set; }
    }
}