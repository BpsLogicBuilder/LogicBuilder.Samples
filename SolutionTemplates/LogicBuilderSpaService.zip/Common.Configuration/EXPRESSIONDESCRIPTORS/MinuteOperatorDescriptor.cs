﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class MinuteOperatorDescriptor : OperatorDescriptorBase
    {
		public OperatorDescriptorBase Operand { get; set; }
    }
}