﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class MonthOperatorDescriptor : OperatorDescriptorBase
    {
		public OperatorDescriptorBase Operand { get; set; }
    }
}