﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class ToLowerOperatorDescriptor : OperatorDescriptorBase
    {
		public OperatorDescriptorBase Operand { get; set; }
    }
}