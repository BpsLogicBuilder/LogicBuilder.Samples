﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class AverageOperatorDescriptor : SelectorMethodOperatorDescriptorBase
    {

    }
}