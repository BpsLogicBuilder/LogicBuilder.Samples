﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class AllOperatorDescriptor : FilterMethodOperatorDescriptorBase
    {

    }
}