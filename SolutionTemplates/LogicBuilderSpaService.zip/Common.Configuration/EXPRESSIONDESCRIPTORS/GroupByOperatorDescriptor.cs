﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class GroupByOperatorDescriptor : SelectorMethodOperatorDescriptorBase
    {

    }
}