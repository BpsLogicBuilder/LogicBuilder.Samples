﻿using $ext_safeprojectname$.Contexts;
using LogicBuilder.EntityFrameworkCore.SqlServer.Crud.DataStores;

namespace $safeprojectname$
{
    public class MyStore : StoreBase, IMyStore
    {
        public MyStore(MyContext context) : base(context)
        {
        }
    }
}
