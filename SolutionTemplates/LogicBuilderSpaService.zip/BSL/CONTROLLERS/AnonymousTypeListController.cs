﻿using AutoMapper;
using $safeprojectname$.Business.Requests;
using $safeprojectname$.Business.Responses;
using $safeprojectname$.Utils;
using $ext_safeprojectname$.Repositories;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace $safeprojectname$.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AnonymousTypeListController : ControllerBase
    {
        private readonly IMapper mapper;
        private readonly IMyRepository repository;

        public AnonymousTypeListController(IMapper mapper, IMyRepository repository)
        {
            this.mapper = mapper;
            this.repository = repository;
        }

        [HttpPost("GetList")]
        public async Task<BaseResponse> GetList([FromBody] GetObjectListRequest request)
        {
            return await RequestHelpers.GetAnonymousList
            (
                request,
                repository,
                mapper
            );
        }
    }
}
