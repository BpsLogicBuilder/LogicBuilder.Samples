﻿using Microsoft.EntityFrameworkCore;

namespace $safeprojectname$.Configuations
{
    interface ITableConfiguration
    {
        void Configure(ModelBuilder modelBuilder);
    }
}
