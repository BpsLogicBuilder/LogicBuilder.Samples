﻿using $ext_safeprojectname$.Common.Configuration.ExpansionDescriptors;

namespace $safeprojectname$.Requests
{
    public class KendoGridDataRequest
    {
        public string DataType { get; set; }
        public string ModelType { get; set; }
        public KendoGridDataSourceRequestOptions Options { get; set; }
        public SelectExpandDefinitionDescriptor SelectExpandDefinition { get; set; }
    }
}
