﻿namespace $safeprojectname$.Settings.Screen
{
    public enum ViewType
    {
        EditForm,
        DetailForm,
        ListPage,
        SearchPage,
        TextPage
    }
}
