﻿using $ext_safeprojectname$.Forms.Configuration.Navigation;
using $safeprojectname$.Cache;
using $safeprojectname$.Settings.Screen;

namespace $safeprojectname$.Settings
{
    public class FlowSettings
    {
        public FlowSettings(FlowState flowState, FlowDataCache flowDataCache, ScreenSettingsBase screenSettings)
        {
            FlowState = flowState;
            FlowDataCache = flowDataCache;
            ScreenSettings = screenSettings;
        }

        public FlowState FlowState { get; set; }
        public FlowDataCache FlowDataCache { get; set; }
        public ScreenSettingsBase ScreenSettings { get; set; }
    }
}
