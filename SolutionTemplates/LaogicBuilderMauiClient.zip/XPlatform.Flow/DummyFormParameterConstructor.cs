﻿using $ext_safeprojectname$.Forms.Parameters;
using $ext_safeprojectname$.Forms.Parameters.Bindings;
using $ext_safeprojectname$.Forms.Parameters.DataForm;
using $ext_safeprojectname$.Forms.Parameters.SearchForm;
using $ext_safeprojectname$.Forms.Parameters.TextForm;

namespace $safeprojectname$
{
    public class DummyFormParameterConstructor
    {
        public DummyFormParameterConstructor
        (
            CommandButtonParameters commandButtonParameters,
            FormControlSettingsParameters formControlSettingsParameters,
            FormGroupArraySettingsParameters formGroupArraySettingsParameters,
            FormGroupSettingsParameters formGroupSettingsParameters,
            FormGroupBoxSettingsParameters groupBoxSettingsParameters,
            MultiSelectFormControlSettingsParameters multiSelectFormControlSettingsParameters,
            SearchFilterGroupParameters searchFilterGroupParameters,
            SearchFilterParameters searchFilterParameters,
            FormattedLabelItemParameters formattedLabelItemParameters,
            HyperLinkLabelItemParameters hyperLinkLabelItemParameters,
            LabelItemParameters labelItemParameters,
            HyperLinkSpanItemParameters hyperLinkSpanItemParameters,
            SpanItemParameters spanItemParameters,
            MultiSelectItemBindingParameters multiSelectItemBindingParameters,
            DropDownItemBindingParameters dropDownItemBindingParameters,
            TextItemBindingParameters textItemBindingParameters
        )
        {
        }
    }
}
