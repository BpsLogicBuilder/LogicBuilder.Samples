﻿using $ext_safeprojectname$.Forms.Parameters.Navigation;
using LogicBuilder.Attributes;

namespace $safeprojectname$
{
    public interface IActions
    {
        [AlsoKnownAs("SetupNavigationMenu")]
        void UpdateNavigationBar(NavigationBarParameters navBar);
    }
}
