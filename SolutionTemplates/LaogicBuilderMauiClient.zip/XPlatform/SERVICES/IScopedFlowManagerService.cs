﻿using $safeprojectname$.Flow;
using $safeprojectname$.Flow.Requests;
using System;
using System.Threading.Tasks;

namespace $safeprojectname$.Services
{
    public interface IScopedFlowManagerService : IDisposable
    {
        IFlowManager FlowManager { get; }
        Task Start();
        Task NewFlowStart(NewFlowRequest request);
        Task RunFlow(NewFlowRequest request);
        Task Next(CommandButtonRequest request);
        void CopyFlowItems();
        void CopyPersistentFlowItems();
        void SetFlowDataCacheItem(string key, object value);
        object? GetFlowDataCacheItem(string key);
    }
}
