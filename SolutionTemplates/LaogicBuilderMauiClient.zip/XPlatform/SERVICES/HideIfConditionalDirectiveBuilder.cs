﻿using AutoMapper;
using $ext_safeprojectname$.Forms.Configuration.DataForm;
using $safeprojectname$.Directives;
using $safeprojectname$.Directives.Factories;
using $safeprojectname$.ViewModels;
using System.Collections.Generic;

namespace $safeprojectname$.Services
{
    public class HideIfConditionalDirectiveBuilder<TModel> : BaseConditionalDirectiveBuilder<HideIf<TModel>, TModel>
    {
        public HideIfConditionalDirectiveBuilder(
            IDirectiveManagersFactory directiveManagersFactory,
            IMapper mapper,
            IFormGroupSettings formGroupSettings,
            IEnumerable<IFormField> properties,
            List<HideIf<TModel>>? parentList = null,
            string? parentName = null) : base(
                directiveManagersFactory,
                mapper,
                formGroupSettings,
                properties,
                parentList,
                parentName)
        {
        }
    }
}
