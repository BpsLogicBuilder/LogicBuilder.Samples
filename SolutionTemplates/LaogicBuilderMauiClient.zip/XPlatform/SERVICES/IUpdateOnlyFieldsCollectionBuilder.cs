﻿namespace $safeprojectname$.Services
{
    public interface IUpdateOnlyFieldsCollectionBuilder : IFieldsCollectionBuilder
    {
    }
}
