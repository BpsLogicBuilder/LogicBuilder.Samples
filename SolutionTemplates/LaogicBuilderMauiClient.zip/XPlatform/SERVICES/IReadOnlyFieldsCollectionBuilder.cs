﻿using $ext_safeprojectname$.Forms.Configuration.DataForm;
using $safeprojectname$.ViewModels;
using System;

namespace $safeprojectname$.Services
{
    public interface IReadOnlyFieldsCollectionBuilder
    {
        DetailFormLayout CreateFields();
    }
}
