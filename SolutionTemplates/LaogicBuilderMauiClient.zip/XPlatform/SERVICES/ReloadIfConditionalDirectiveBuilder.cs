﻿using AutoMapper;
using $ext_safeprojectname$.Forms.Configuration.DataForm;
using $safeprojectname$.Directives;
using $safeprojectname$.Directives.Factories;
using $safeprojectname$.ViewModels;
using System.Collections.Generic;

namespace $safeprojectname$.Services
{
    public class ReloadIfConditionalDirectiveBuilder<TModel> : BaseConditionalDirectiveBuilder<ReloadIf<TModel>, TModel>
    {
        public ReloadIfConditionalDirectiveBuilder(
            IDirectiveManagersFactory directiveManagersFactory,
            IMapper mapper,
            IFormGroupSettings formGroupSettings,
            IEnumerable<IFormField> properties,
            List<ReloadIf<TModel>>? parentList = null,
            string? parentName = null) : base(
                directiveManagersFactory,
                mapper,
                formGroupSettings,
                properties,
                parentList,
                parentName)
        {
        }
    }
}
