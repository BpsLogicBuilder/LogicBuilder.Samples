﻿using $ext_safeprojectname$.Forms.Configuration.DataForm;
using $safeprojectname$.ViewModels.ReadOnlys;
using System.Collections.Generic;

namespace $safeprojectname$.Services
{
    public interface IReadOnlyPropertiesUpdater
    {
        void UpdateProperties(IEnumerable<IReadOnly> properties, object? entity, List<FormItemSettingsDescriptor> fieldSettings, string? parentField = null);
    }
}
