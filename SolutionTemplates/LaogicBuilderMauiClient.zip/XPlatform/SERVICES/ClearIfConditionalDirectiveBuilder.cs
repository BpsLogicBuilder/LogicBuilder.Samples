﻿using AutoMapper;
using $ext_safeprojectname$.Forms.Configuration.DataForm;
using $safeprojectname$.Directives;
using $safeprojectname$.Directives.Factories;
using $safeprojectname$.ViewModels;
using System.Collections.Generic;

namespace $safeprojectname$.Services
{
    public class ClearIfConditionalDirectiveBuilder<TModel> : BaseConditionalDirectiveBuilder<ClearIf<TModel>, TModel>
    {
        public ClearIfConditionalDirectiveBuilder(
            IDirectiveManagersFactory directiveManagersFactory,
            IMapper mapper,
            IFormGroupSettings formGroupSettings,
            IEnumerable<IFormField> properties,
            List<ClearIf<TModel>>? parentList = null,
            string? parentName = null) : base(
                directiveManagersFactory,
                mapper,
                formGroupSettings,
                properties,
                parentList,
                parentName)
        {
        }
    }
}
