﻿using $ext_safeprojectname$.Forms.Configuration.Bindings;
using $safeprojectname$.ViewModels.ReadOnlys;
using System;
using System.Collections.Generic;

namespace $safeprojectname$.Services
{
    public interface ICollectionCellItemsBuilder
    {
        ICollection<IReadOnly> CreateFields();
    }
}
