﻿using $safeprojectname$.ViewModels;

namespace $safeprojectname$.Services
{
    public interface IFieldsCollectionBuilder
    {
        EditFormLayout CreateFields();
    }
}
