﻿using AutoMapper;
using $ext_safeprojectname$.AutoMapperProfiles;
using $safeprojectname$.AutoMapperProfiles;
using $safeprojectname$.MappingProfiles;

namespace Microsoft.Extensions.DependencyInjection
{
    internal static class AutoMapperServices
    {
        internal static IServiceCollection AddAutoMapperServices(this IServiceCollection services)
        {
            return services.AddSingleton<IConfigurationProvider>
                (
                    new MapperConfiguration(cfg =>
                    {
                        cfg.AddMaps(typeof(DescriptorToOperatorMappingProfile), typeof(CommandButtonProfile), typeof(MenuItemProfile));
                        cfg.AllowNullCollections = true;
                    })
                ).AddTransient<IMapper>
                (
                    sp => new Mapper
                    (
                        sp.GetRequiredService<AutoMapper.IConfigurationProvider>(),
                        sp.GetService
                    )
                );
        }
    }
}
