﻿using $ext_safeprojectname$.Forms.Configuration.Bindings;
using $safeprojectname$.ViewModels.ReadOnlys;
using System;
using System.Collections.Generic;

namespace $safeprojectname$.Services
{
    public interface IReadOnlyCollectionCellPropertiesUpdater
    {
        void UpdateProperties(IEnumerable<IReadOnly> properties, Type modelType, object entity, List<ItemBindingDescriptor> itemBindings);
    }
}
