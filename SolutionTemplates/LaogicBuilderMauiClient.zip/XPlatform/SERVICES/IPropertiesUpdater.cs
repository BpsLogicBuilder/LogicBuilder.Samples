﻿using $ext_safeprojectname$.Forms.Configuration.DataForm;
using $safeprojectname$.ViewModels.Validatables;
using System.Collections.Generic;

namespace $safeprojectname$.Services
{
    public interface IPropertiesUpdater
    {
        void UpdateProperties(IEnumerable<IValidatable> properties, object? entity, List<FormItemSettingsDescriptor> FieldSettings, string? parentField = null);
    }
}
