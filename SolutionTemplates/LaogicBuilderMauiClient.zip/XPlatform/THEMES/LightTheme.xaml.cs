using Microsoft.Maui.Controls;

namespace $safeprojectname$.Themes;

public partial class LightTheme : ResourceDictionary
{
	public LightTheme()
	{
		InitializeComponent();
	}
}