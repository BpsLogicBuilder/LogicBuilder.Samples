using Microsoft.Maui.Controls;

namespace $safeprojectname$.Themes;

public partial class DarkTheme : ResourceDictionary
{
	public DarkTheme()
	{
		InitializeComponent();
	}
}