﻿namespace $safeprojectname$.Constants
{
    public struct AppConstants
    {
        public const string ApplicationName = "$safeprojectname$";
    }
}
