﻿namespace $safeprojectname$.Constants
{
    public struct FromGroupTemplateNames
    {
        public const string InlineFormGroupTemplate = "InlineFormGroupTemplate";
        public const string PopupFormGroupTemplate = "PopupFormGroupTemplate";
    }
}
