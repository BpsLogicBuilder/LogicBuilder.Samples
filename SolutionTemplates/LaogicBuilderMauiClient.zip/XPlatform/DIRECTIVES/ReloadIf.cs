﻿namespace $safeprojectname$.Directives
{
    public class ReloadIf<T> : ConditionBase<T>
    {
    }
}
