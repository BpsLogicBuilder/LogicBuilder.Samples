﻿using AutoMapper;
using $ext_safeprojectname$.Forms.Configuration.Navigation;
using $safeprojectname$.ViewModels;

namespace $safeprojectname$.MappingProfiles
{
    public class MenuItemProfile : Profile
    {
        public MenuItemProfile()
        {
            CreateMap<NavigationMenuItemDescriptor, FlyoutMenuItem>();
        }
    }
}
