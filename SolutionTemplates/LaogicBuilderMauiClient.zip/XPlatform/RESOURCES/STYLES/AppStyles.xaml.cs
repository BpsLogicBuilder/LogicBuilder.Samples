using Microsoft.Maui.Controls;

namespace $safeprojectname$.Resources.Styles;

public partial class AppStyles : ResourceDictionary
{
	public AppStyles()
	{
		InitializeComponent();
	}
}