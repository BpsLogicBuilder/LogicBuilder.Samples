﻿using Android.Util;
using $safeprojectname$.Flow;

namespace $safeprojectname$
{
    public class AppLogger : IAppLogger
    {
        public void LogMessage(string group, string message)
        {
            Log.Debug($"X:{group}", message);
        }
    }
}
