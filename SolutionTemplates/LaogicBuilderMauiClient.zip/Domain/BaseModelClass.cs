﻿using LogicBuilder.Domain;

namespace $safeprojectname$
{
    abstract public class BaseModelClass : BaseModel
    {
        public string TypeFullName => this.GetType().AssemblyQualifiedName;
    }
}
