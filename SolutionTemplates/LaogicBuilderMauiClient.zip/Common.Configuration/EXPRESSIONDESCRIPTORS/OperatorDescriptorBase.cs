﻿using $safeprojectname$.Json;
using System.Text.Json.Serialization;

namespace $safeprojectname$.ExpressionDescriptors
{
    [JsonConverter(typeof(DescriptorConverter))]
    public abstract class OperatorDescriptorBase : IExpressionOperatorDescriptor
    {
        public string TypeString => this.GetType().AssemblyQualifiedName;
    }
}
