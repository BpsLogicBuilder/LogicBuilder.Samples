﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class OrBinaryOperatorDescriptor : BinaryOperatorDescriptor
    {

    }
}