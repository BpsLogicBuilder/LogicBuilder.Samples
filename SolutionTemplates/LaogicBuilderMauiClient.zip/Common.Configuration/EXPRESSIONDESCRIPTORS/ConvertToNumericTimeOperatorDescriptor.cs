﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class ConvertToNumericTimeOperatorDescriptor : OperatorDescriptorBase
    {
		public OperatorDescriptorBase SourceOperand { get; set; }
    }
}