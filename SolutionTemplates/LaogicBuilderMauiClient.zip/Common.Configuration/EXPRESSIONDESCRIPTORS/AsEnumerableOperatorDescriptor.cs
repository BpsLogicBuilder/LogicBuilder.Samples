﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class AsEnumerableOperatorDescriptor : OperatorDescriptorBase
    {
		public OperatorDescriptorBase SourceOperand { get; set; }
    }
}