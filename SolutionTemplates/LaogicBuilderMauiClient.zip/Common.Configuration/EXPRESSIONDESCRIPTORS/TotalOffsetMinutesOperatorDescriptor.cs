﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class TotalOffsetMinutesOperatorDescriptor : OperatorDescriptorBase
    {
		public OperatorDescriptorBase Operand { get; set; }
    }
}