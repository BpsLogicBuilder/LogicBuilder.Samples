﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class MaxOperatorDescriptor : SelectorMethodOperatorDescriptorBase
    {

    }
}