﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class AsQueryableOperatorDescriptor : OperatorDescriptorBase
    {
		public OperatorDescriptorBase SourceOperand { get; set; }
    }
}