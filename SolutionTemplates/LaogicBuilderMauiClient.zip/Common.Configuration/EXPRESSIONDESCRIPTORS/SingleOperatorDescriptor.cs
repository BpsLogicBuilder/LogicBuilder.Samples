﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class SingleOperatorDescriptor : FilterMethodOperatorDescriptorBase
    {

    }
}