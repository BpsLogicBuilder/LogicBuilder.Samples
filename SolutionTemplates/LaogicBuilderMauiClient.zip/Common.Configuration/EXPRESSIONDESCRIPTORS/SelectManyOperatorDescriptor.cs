﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class SelectManyOperatorDescriptor : SelectorMethodOperatorDescriptorBase
    {

    }
}