﻿namespace $safeprojectname$.ExpressionDescriptors
{
    public class FirstOperatorDescriptor : FilterMethodOperatorDescriptorBase
    {

    }
}