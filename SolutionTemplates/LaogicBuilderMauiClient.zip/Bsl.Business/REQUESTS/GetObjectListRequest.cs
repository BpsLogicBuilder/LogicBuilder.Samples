﻿using $ext_safeprojectname$.Common.Configuration.ExpansionDescriptors;
using $ext_safeprojectname$.Common.Configuration.ExpressionDescriptors;

namespace $safeprojectname$.Requests
{
    public class GetObjectListRequest : BaseRequest
    {
        public SelectorLambdaOperatorDescriptor Selector { get; set; }
        public SelectExpandDefinitionDescriptor SelectExpandDefinition { get; set; }
        public string ModelType { get; set; }
        public string DataType { get; set; }
    }
}
