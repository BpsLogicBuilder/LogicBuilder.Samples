﻿using System.Collections.Generic;

namespace $safeprojectname$.Responses
{
    public class GetObjectListResponse : BaseResponse
    {
        public IEnumerable<object> List { get; set; }
    }
}
