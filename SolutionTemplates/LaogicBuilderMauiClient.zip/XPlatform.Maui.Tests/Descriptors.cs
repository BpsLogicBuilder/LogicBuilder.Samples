﻿using $ext_safeprojectname$.Common.Configuration.ExpressionDescriptors;
using $ext_safeprojectname$.Data.Entities;
using $ext_safeprojectname$.Domain.Entities;
using $ext_safeprojectname$.Forms.Configuration;
using $ext_safeprojectname$.Forms.Configuration.Bindings;
using $ext_safeprojectname$.Forms.Configuration.DataForm;
using $ext_safeprojectname$.Forms.Configuration.Navigation;
using $ext_safeprojectname$.Forms.Configuration.Validation;
using System;
using System.Collections.Generic;
using System.Linq;

namespace $safeprojectname$
{
    internal static class Descriptors
    {
        internal static DataFormSettingsDescriptor PersonForm = new()
        {
            Title = "Person",
            RequestDetails = new FormRequestDetailsDescriptor
            {
                GetUrl = "/Person/GetSingle"
            },
            ValidationMessages = new List<ValidationMessageDescriptor>
            {
                new ValidationMessageDescriptor
                {
                    Field = "FirstName",
                    Rules = new List<ValidationRuleDescriptor>
                    {
                        new ValidationRuleDescriptor { ClassName = "RequiredRule", Message = "First Name is required." }
                    }
                },
                new ValidationMessageDescriptor
                {
                    Field = "LastName",
                    Rules = new List<ValidationRuleDescriptor>
                    {
                        new ValidationRuleDescriptor { ClassName = "RequiredRule", Message = "Last Name is required." }
                    }
                },
                new ValidationMessageDescriptor
                {
                    Field = "DateOfBirth",
                    Rules = new List<ValidationRuleDescriptor>
                    {
                        new ValidationRuleDescriptor { ClassName = "RequiredRule", Message = "Enrollment Date is required." }
                    }
                }
            }.ToDictionary(v => v.Field, v => v.Rules),
            FieldSettings = new List<FormItemSettingsDescriptor>
            {
                new FormControlSettingsDescriptor
                {
                    Field = "FirstName",
                    Type = "System.String",
                    Title = "First Name",
                    Placeholder = "First Name (required)",
                    TextTemplate = new TextFieldTemplateDescriptor { TemplateName = "TextTemplate" },
                    ValidationSetting = new FieldValidationSettingsDescriptor
                    {
                        DefaultValue = "",
                        Validators = new List<ValidatorDefinitionDescriptor>
                        {
                            new ValidatorDefinitionDescriptor
                            {
                                ClassName = "RequiredRule",
                                FunctionName = "Check"
                            }
                        }
                    }
                },
                new FormControlSettingsDescriptor
                {
                    Field = "LastName",
                    Type = "System.String",
                    Title = "Last Name",
                    Placeholder = "Last Name (required)",
                    TextTemplate = new TextFieldTemplateDescriptor { TemplateName = "TextTemplate" },
                    ValidationSetting = new FieldValidationSettingsDescriptor
                    {
                        DefaultValue = "",
                        Validators = new List<ValidatorDefinitionDescriptor>
                        {
                            new ValidatorDefinitionDescriptor
                            {
                                ClassName = "RequiredRule",
                                FunctionName = "Check"
                            }
                        }
                    }
                },
                new FormControlSettingsDescriptor
                {
                    Field = "DateOfBirth",
                    Type = "System.DateTime",
                    Title = "Date of Birth",
                    Placeholder = "",
                    TextTemplate = new TextFieldTemplateDescriptor { TemplateName = "DateTemplate" },
                    ValidationSetting = new FieldValidationSettingsDescriptor
                    {
                        DefaultValue = new DateTime(1900, 1, 1),
                        Validators = new List<ValidatorDefinitionDescriptor>
                        {
                            new ValidatorDefinitionDescriptor
                            {
                                ClassName = "RequiredRule",
                                FunctionName = "Check"
                            }
                        }
                    }
                }
            },
            ConditionalDirectives = new List<Forms.Configuration.Directives.VariableDirectivesDescriptor>
            {
                new Forms.Configuration.Directives.VariableDirectivesDescriptor
                {
                    Field = "DateOfBirth",
                    ConditionalDirectives = new List<Forms.Configuration.Directives.DirectiveDescriptor>
                    {
                        new Forms.Configuration.Directives.DirectiveDescriptor
                        {
                            Definition = new Forms.Configuration.Directives.DirectiveDefinitionDescriptor
                            {
                                ClassName = "ValidateIf",
                                FunctionName = "Check"
                            },
                            Condition = new Common.Configuration.ExpressionDescriptors.FilterLambdaOperatorDescriptor
                            {
                                SourceElementType = typeof(Domain.Entities.PersonModel).AssemblyQualifiedName,
                                ParameterName = "f",
                                FilterBody = new Common.Configuration.ExpressionDescriptors.EqualsBinaryOperatorDescriptor
                                {
                                    Left = new Common.Configuration.ExpressionDescriptors.MemberSelectorOperatorDescriptor
                                    {
                                        MemberFullName = "FirstName",
                                        SourceOperand = new Common.Configuration.ExpressionDescriptors.ParameterOperatorDescriptor{ ParameterName = "f" }
                                    },
                                    Right = new Common.Configuration.ExpressionDescriptors.MemberSelectorOperatorDescriptor
                                    {
                                        MemberFullName = "LastName",
                                        SourceOperand = new Common.Configuration.ExpressionDescriptors.ParameterOperatorDescriptor{ ParameterName = "f" }
                                    }
                                }
                            }
                        }
                    }
                }
            }.ToDictionary(vd => vd.Field, vd => vd.ConditionalDirectives),
            ModelType = "$ext_safeprojectname$.Domain.Entities.PersonModel, $ext_safeprojectname$.Domain, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null"
        };

        internal static IList<CommandButtonDescriptor> ButtonDescriptors = new List<CommandButtonDescriptor>
        {
            new CommandButtonDescriptor { Id = 1, LongString = "Save", ShortString = "S", Command = "SubmitCommand", ButtonIcon = "Save" },
            new CommandButtonDescriptor { Id = 2, LongString = "Home", ShortString = "H", Command = "NavigateCommand", ButtonIcon = "Home" }
        };

        internal static NavigationBarDescriptor GetNavigationBar(string currentModule) => new()
        {
            BrandText = "$ext_safeprojectname$",
            CurrentModule = currentModule,
            MenuItems = new List<NavigationMenuItemDescriptor>
            {
                new NavigationMenuItemDescriptor
                {
                    InitialModule = "home",
                    Icon = "Home",
                    Text = "Home"
                },
                new NavigationMenuItemDescriptor
                {
                    InitialModule = "about",
                    Icon = "University",
                    Text = "About"
                },
                new NavigationMenuItemDescriptor
                {
                    InitialModule = "students",
                    Icon = "Users",
                    Text = "Persons"
                }
            }
        };
    }
}
