﻿using $ext_safeprojectname$.Domain.Entities;
using $ext_safeprojectname$.Forms.Configuration.DataForm;
using $safeprojectname$.Helpers;
using $ext_safeprojectname$.XPlatform.Services;
using $ext_safeprojectname$.XPlatform.ViewModels;
using $ext_safeprojectname$.XPlatform.ViewModels.Factories;
using $ext_safeprojectname$.XPlatform.ViewModels.Validatables;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Xunit;

namespace $safeprojectname$
{
    public class FieldsCollectionBuilderTest
    {
        public FieldsCollectionBuilderTest()
        {
            serviceProvider = ServiceProviderHelper.GetServiceProvider();
        }

        #region Fields
        private readonly IServiceProvider serviceProvider;
        #endregion Fields

        [Fact]
        public void MapPersonModelToIValidatableList()
        {
            //act
            ObservableCollection<IValidatable> properties = GetFieldsCollectionBuilder
            (
                Descriptors.PersonForm,
                typeof(PersonModel)
            )
            .CreateFields()
            .Properties;

            //assert
            IDictionary<string, IValidatable> propertiesDictionary = properties.ToDictionary(property => property.Name);
            Assert.Equal(typeof(EntryValidatableObject<string>), propertiesDictionary["FirstName"].GetType());
        }

        private IFieldsCollectionBuilder GetFieldsCollectionBuilder(DataFormSettingsDescriptor dataFormSettingsDescriptor, Type modelType)
        {
            return serviceProvider.GetRequiredService<ICollectionBuilderFactory>().GetFieldsCollectionBuilder
            (
                modelType,
                dataFormSettingsDescriptor.FieldSettings,
                dataFormSettingsDescriptor,
                dataFormSettingsDescriptor.ValidationMessages,
                null,
                null
            );
        }
    }
}
