﻿using $ext_safeprojectname$.Domain.Entities;
using $ext_safeprojectname$.Forms.Configuration;
using $ext_safeprojectname$.Forms.Configuration.Bindings;
using $safeprojectname$.Helpers;
using $ext_safeprojectname$.XPlatform.Services;
using $ext_safeprojectname$.XPlatform.ViewModels.Factories;
using $ext_safeprojectname$.XPlatform.ViewModels.ReadOnlys;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using Xunit;

namespace $safeprojectname$
{
    public class CollectionCellItemsBuilderTest
    {
        public CollectionCellItemsBuilderTest()
        {
            serviceProvider = ServiceProviderHelper.GetServiceProvider();
        }

        #region Fields
        private readonly IServiceProvider serviceProvider;
        #endregion Fields
        [Fact]
        public void CreateReadOnlyPropertiesForPersonModel()
        {
            ICollection<IReadOnly> properties = GetCollectionCellItemsBuilder
            (
                new List<ItemBindingDescriptor>
                {
                    new TextItemBindingDescriptor
                    {
                        Name = "Text",
                        Property = "DateOfBirth",
                        StringFormat = "{0:MMMM dd, yyyy}",
                        TextTemplate = new TextFieldTemplateDescriptor { TemplateName = "DateTemplate" }
                    },
                    new TextItemBindingDescriptor
                    {
                        Name = "Detail",
                        Property = "FullName",
                        StringFormat = "{0}",
                        TextTemplate = new TextFieldTemplateDescriptor { TemplateName = "TextTemplate" }
                    }
                },
                typeof(PersonModel)
            ).CreateFields();

            Assert.Equal(2, properties.Count);
        }

        private ICollectionCellItemsBuilder GetCollectionCellItemsBuilder(List<ItemBindingDescriptor> bindingDescriptors, Type modelType)
        {
            return serviceProvider.GetRequiredService<ICollectionBuilderFactory>().GetCollectionCellItemsBuilder
            (
                modelType,
                bindingDescriptors
            );
        }
    }
}
