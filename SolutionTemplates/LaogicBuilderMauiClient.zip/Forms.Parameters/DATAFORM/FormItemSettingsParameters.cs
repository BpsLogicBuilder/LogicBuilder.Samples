﻿namespace $safeprojectname$.DataForm
{
    abstract public class FormItemSettingsParameters
    {
    }
}