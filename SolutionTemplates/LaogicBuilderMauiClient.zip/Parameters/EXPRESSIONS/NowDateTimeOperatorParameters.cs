﻿namespace $safeprojectname$.Expressions
{
    public class NowDateTimeOperatorParameters : IExpressionParameter
    {
		public NowDateTimeOperatorParameters()
		{
		}
    }
}