﻿using $safeprojectname$.Expressions;

namespace $safeprojectname$.Expansions
{
    public class SelectExpandItemFilterParameters
    {
        public SelectExpandItemFilterParameters()
        {
        }

        public SelectExpandItemFilterParameters(FilterLambdaOperatorParameters filterLambdaOperator)
        {
            FilterLambdaOperator = filterLambdaOperator;
        }

        public FilterLambdaOperatorParameters FilterLambdaOperator { get; set; }
    }
}
