﻿namespace $safeprojectname$
{
    public class FormGroupTemplateDescriptor
    {
        public string TemplateName { get; set; }
    }
}
