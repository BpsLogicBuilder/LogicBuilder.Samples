﻿using $ext_safeprojectname$.Utils;

namespace $safeprojectname$.TextForm.Json
{
    public class LabelItemDescriptorConverter : JsonTypeConverter<LabelItemDescriptorBase>
    {
        public override string TypePropertyName => "TypeString";
    }
}
