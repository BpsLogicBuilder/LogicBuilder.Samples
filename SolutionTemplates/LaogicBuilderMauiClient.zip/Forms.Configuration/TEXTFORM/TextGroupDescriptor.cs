﻿using System.Collections.Generic;

namespace $safeprojectname$.TextForm
{
    public class TextGroupDescriptor
    {
        public string Title { get; set; }
        public List<LabelItemDescriptorBase> Labels { get; set; }
    }
}
