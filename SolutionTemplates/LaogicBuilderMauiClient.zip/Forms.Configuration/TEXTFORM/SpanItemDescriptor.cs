﻿namespace $safeprojectname$.TextForm
{
    public class SpanItemDescriptor : SpanItemDescriptorBase
    {
        public string Text { get; set; }
    }
}
