﻿using System.Collections.Generic;

namespace $safeprojectname$.TextForm
{
    public class FormattedLabelItemDescriptor : LabelItemDescriptorBase
    {
        public List<SpanItemDescriptorBase> Items { get; set; }
    }
}
