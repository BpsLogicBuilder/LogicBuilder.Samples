﻿using $safeprojectname$.TextForm.Json;
using System.Text.Json.Serialization;

namespace $safeprojectname$.TextForm
{
    [JsonConverter(typeof(LabelItemDescriptorConverter))]
    public abstract class LabelItemDescriptorBase
    {
        public string TypeString => this.GetType().AssemblyQualifiedName;
    }
}
