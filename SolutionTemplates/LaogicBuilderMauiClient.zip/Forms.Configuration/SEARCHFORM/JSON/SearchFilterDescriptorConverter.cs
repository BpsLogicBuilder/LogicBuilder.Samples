﻿using $ext_safeprojectname$.Utils;

namespace $safeprojectname$.SearchForm.Json
{
    public class SearchFilterDescriptorConverter : JsonTypeConverter<SearchFilterDescriptorBase>
    {
        public override string TypePropertyName => "TypeString";
    }
}
