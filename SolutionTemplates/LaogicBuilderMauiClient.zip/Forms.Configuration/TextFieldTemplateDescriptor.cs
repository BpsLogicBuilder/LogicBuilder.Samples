﻿namespace $safeprojectname$
{
    public class TextFieldTemplateDescriptor
    {
        public string TemplateName { get; set; }
    }
}
