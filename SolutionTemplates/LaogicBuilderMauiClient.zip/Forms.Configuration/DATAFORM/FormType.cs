﻿namespace $safeprojectname$.DataForm
{
    public enum FormType
    {
        Add,
        Update,
        Delete,
        Detail
    }
}
