﻿using $safeprojectname$.Directives;
using $safeprojectname$.Validation;
using System.Collections.Generic;

namespace $safeprojectname$.DataForm
{
    public interface IFormGroupSettings : IFormGroupBoxSettings
    {
        string ModelType { get; }
        string Title { get; }
        Dictionary<string, List<DirectiveDescriptor>> ConditionalDirectives { get; }
        Dictionary<string, List<ValidationRuleDescriptor>> ValidationMessages { get; }
    }
}
