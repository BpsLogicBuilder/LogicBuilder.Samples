﻿using $ext_safeprojectname$.Common.Configuration.ExpressionDescriptors;

namespace $safeprojectname$.Directives
{
    public class DirectiveDescriptor
    {
        public DirectiveDefinitionDescriptor Definition { get; set; }
        public FilterLambdaOperatorDescriptor Condition { get; set; }
    }
}
