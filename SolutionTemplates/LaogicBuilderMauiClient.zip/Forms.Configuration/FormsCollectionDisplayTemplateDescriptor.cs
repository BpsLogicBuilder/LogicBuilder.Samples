﻿using $safeprojectname$.Bindings;
using System.Collections.Generic;

namespace $safeprojectname$
{
    public class FormsCollectionDisplayTemplateDescriptor
    {
        public string TemplateName { get; set; }
        public Dictionary<string, ItemBindingDescriptor> Bindings { get; set; }
    }
}
